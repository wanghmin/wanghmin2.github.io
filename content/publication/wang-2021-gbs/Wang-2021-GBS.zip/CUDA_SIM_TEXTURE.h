///////////////////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 2002 - 2020, Huamin Wang
//  All rights reserved.
//  Redistribution and use in source and binary formats, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//     1. Redistributions of source code must retain the above copyright
//        notice, this list of conditions and the following disclaimer.
//     2. Redistributions in binary form must reproduce the above copyright
//        notice, this list of conditions and the following disclaimer in the
//        documentation and/or other materials provided with the distribution.
//     3. The names of its contributors may not be used to endorse or promote
//        products derived from this software without specific prior written
//        permission.
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EIENT SHALL THE COPYRIGHT OWNER OR
//  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
//  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
//  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
//  PROFITS; OR BUSINESS INTERRUPTION) HOWEIER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//	NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EIEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
///////////////////////////////////////////////////////////////////////////////////////////
//  Class CUDA_SIM_TEXTURE
///////////////////////////////////////////////////////////////////////////////////////////
#pragma once
#include "SIM_TEXTURE.h"
#include "CUDA_LEVEL_SET.h"
#include <thrust/reduce.h>
#include <thrust/device_vector.h>

__constant__ float dev_compact_bend_data[256][12];

///////////////////////////////////////////////////////////////////////////////////////////
//  PCG_Kernel
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void PCG_Kernel(
		  float* __restrict__ X,
		  float* __restrict__ S,
	const float* __restrict__ dX,
	const char*	 __restrict__ M,
	const float beta,
	const float alpha,
	const int number)
{
	int id = blockDim.x * blockIdx.x + threadIdx.x;
	if(id>=number)		return;
	if(M[id/3]<=0)		return;

	S[id]=dX[id]+beta*S[id];
	X[id]=X[id]+alpha*S[id];
}

///////////////////////////////////////////////////////////////////////////////////////////
//  Set_Coord_Kernel
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void Set_Coord_Kernel(
		  float* __restrict__ coord,
	const float* __restrict__ X,
	const float* __restrict__ init_X,
	const float* __restrict__ init_XN,
	const float* __restrict__ init_XG,
	const char*	 __restrict__ M,
	const float* __restrict__ G,	
	const int ni, const int nj)
{
	int i = blockDim.x * blockIdx.x + threadIdx.x;
	int j = blockDim.y * blockIdx.y + threadIdx.y;
	if(i>=ni)			return;
	if(j>=nj)			return;
	int id=INDEX(i, j);
	if(M[id]<=0)		return;

	const float* xN=&init_XN[id*3];
	const float* xG=&init_XG[id*3];
	float  xT[3];
	CROSS(xN, xG, xT);

	float u[3];
	u[0]=X[id*3+0]-init_X[id*3+0];
	u[1]=X[id*3+1]-init_X[id*3+1];
	u[2]=X[id*3+2]-init_X[id*3+2];

	coord[id*3+0]=DOT(u, xN);
	coord[id*3+1]=DOT(u, xG);
	coord[id*3+2]=DOT(u, xT);

	//if(coord[id*3+0]<0)	coord[id*3+0]=0;
}

///////////////////////////////////////////////////////////////////////////////////////////
//  Apply_Coord_Kernel
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void Apply_Coord_Kernel(
	const float* __restrict__ coord,
		  float* __restrict__ X,
	const float* __restrict__ init_X,
	const float* __restrict__ init_XN,
	const float* __restrict__ init_XG,
	const char*	 __restrict__ M,
	const float* __restrict__ G,	
	const int ni, const int nj)
{
	int i = blockDim.x * blockIdx.x + threadIdx.x;
	int j = blockDim.y * blockIdx.y + threadIdx.y;
	if(i>=ni)			return;
	if(j>=nj)			return;
	int id=INDEX(i, j);
	if(M[id]<=0)		return;

	//if(G[id*4+2]==1)	return;

	const float* xN=&init_XN[id*3];
	const float* xG=&init_XG[id*3];
	float  xT[3];
	CROSS(xN, xG, xT);

	X[id*3+0]=init_X[id*3+0];
	X[id*3+1]=init_X[id*3+1];
	X[id*3+2]=init_X[id*3+2];

	float temp[3];
	temp[0]=coord[id*3+0]*xN[0]+coord[id*3+1]*xG[0]+coord[id*3+2]*xT[0];
	temp[1]=coord[id*3+0]*xN[1]+coord[id*3+1]*xG[1]+coord[id*3+2]*xT[1];
	temp[2]=coord[id*3+0]*xN[2]+coord[id*3+1]*xG[2]+coord[id*3+2]*xT[2];
	if(isnan(temp[0]))		return;
	if(isnan(temp[1]))		return;
	if(isnan(temp[2]))		return;
	X[id*3+0]+=temp[0];
	X[id*3+1]+=temp[1];
	X[id*3+2]+=temp[2];
}

///////////////////////////////////////////////////////////////////////////////////////////
//  Body_Projection_Kernel
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void Body_Projection_Kernel(
		  float* __restrict__ init_X,
		  float* __restrict__ proj_X,
		  char*	 __restrict__ M,
	cudaTextureObject_t phi_texture,
	const float body_h,	const float * __restrict__ body_txyz,
	const int ni, const int nj)
{
	int i = blockDim.x * blockIdx.x + threadIdx.x;
	int j = blockDim.y * blockIdx.y + threadIdx.y;
	if(i>=ni)			return;
	if(j>=nj)			return;
	int id=INDEX(i, j);
	if(M[id]<=0)		return;

	if(phi_texture)
	{
		float body_tx = body_txyz[0];
		float body_ty = body_txyz[1];
		float body_tz = body_txyz[2];
		
		float g[3], h[3], d;
		d=dev_LS_Gradient_and_DHessian(phi_texture, init_X[id*3+0], init_X[id*3+1], init_X[id*3+2], g[0], g[1], g[2], h[0], h[1], h[2], body_h, body_tx, body_ty, body_tz, 0.01f);

		float g_length=sqrtf(DOT(g, g));
		if(g_length>1e-12f)
		{
			g[0]/=g_length;
			g[1]/=g_length;
			g[2]/=g_length;
		}

		proj_X[id*3+0]=init_X[id*3+0]-d*g[0];
		proj_X[id*3+1]=init_X[id*3+1]-d*g[1];
		proj_X[id*3+2]=init_X[id*3+2]-d*g[2];		

		if(d<0)
		{
			init_X[id*3+0]=proj_X[id*3+0]+0.0004f*g[0];
			init_X[id*3+1]=proj_X[id*3+1]+0.0004f*g[1];
			init_X[id*3+2]=proj_X[id*3+2]+0.0004f*g[2];
		}

		M[id]=VALID_MASK;
		if(g[0] || g[1] || g[2])	M[id]=BODY_VALID_MASK;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
//  Energy_Kernel
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void Energy_Kernel(
		  float* __restrict__ energy, 
	const float* __restrict__ X,
	const char*  __restrict__ M,
	const half2* __restrict__ spring_data, 
	const int*   __restrict__ bend_ID,
	const float spring_k,
	const float bending_k,
	const float air_k,
	const int ni, const int nj)
{
	int i = blockDim.x * blockIdx.x + threadIdx.x;
	int j = blockDim.y * blockIdx.y + threadIdx.y;
	if(i>=ni)	return;
	if(j>=nj)	return;

	//Skip if the node doesn't touch moveable region.
	int id=INDEX(i, j);
	if(M[id]==EMPTY_MASK)
	{
		energy[id]=0;
		return;
	}
	bool tag=false;
	for(int ii=-2; ii<=2; ii++)
	for(int jj=-2; jj<=2; jj++)
		if(M[INDEX(i+ii, j+jj)]>0)		tag=true;
	if(tag==false)
	{
		energy[id]=0;
		return;
	}

	int bid=bend_ID[id];
	int number=ni*nj;
	float ret=0;

	float f[3]{};

	float last_u[3]{};
	if(i-1>=0 && i-1<ni && j+1>=0 && j+1<nj && M[INDEX(i-1, j+1)]!=EMPTY_MASK)
	{
		last_u[0]=X[id*3+0]-X[INDEX(i-1,j+1)*3+0];
		last_u[1]=X[id*3+1]-X[INDEX(i-1,j+1)*3+1];
		last_u[2]=X[id*3+2]-X[INDEX(i-1,j+1)*3+2];
	}

	half s[6]={
		spring_data[0*ni*nj+id].x,
		spring_data[0*ni*nj+id].y,
		spring_data[1*ni*nj+id].x,
		spring_data[1*ni*nj+id].y,
		spring_data[2*ni*nj+id].x,
		spring_data[2*ni*nj+id].y};	

	for(int n=0; n<6; n++)
	{
		int oi, oj;
			 if(n==0)	{oi=-1; oj= 0;}
		else if(n==1)	{oi= 0; oj=-1;}
		else if(n==2)	{oi= 1; oj=-1;}
		else if(n==3)	{oi= 1; oj= 0;}
		else if(n==4)	{oi= 0; oj= 1;}
		else if(n==5)	{oi=-1; oj= 1;}
		if(i+oi<0 || i+oi>=ni)	continue;
		if(j+oj<0 || j+oj>=nj)	continue;

		int nid=INDEX(i+oi, j+oj);
		float u[3];
		u[0]=X[id*3+0]-X[nid*3+0];
		u[1]=X[id*3+1]-X[nid*3+1];
		u[2]=X[id*3+2]-X[nid*3+2];
			
		float v;
		//spring
		if(v=s[n])
		{
			ret+=(u[0]*last_u[1]-u[1]*last_u[0])*(last_u[2]+u[2]-X[id*3+2])*air_k;
			last_u[0]=u[0];
			last_u[1]=u[1];
			last_u[2]=u[2];

			float planar_k = spring_k/v;		// Young's modulus fix
			float mag_u=sqrtf(u[0]*u[0]+u[1]*u[1]+u[2]*u[2]);
			ret+=0.25f*planar_k*(v-mag_u)*(v-mag_u);
		}	
		else
		{
			last_u[0]=0;
			last_u[1]=0;
			last_u[2]=0;
		}
		//bending
		if(n==2 || n==5)	v=-4*bending_k;
		else				v=12*bending_k;
		f[0]-=v*u[0];
		f[1]-=v*u[1];
		f[2]-=v*u[2];
	}

	for(int n=6; n<12; n++)
	{
		float v;//=dev_compact_bend_data[bid][n]*bending_k;			
		if((i+j)%2==0)
		{
			if(n==6 || n==7)	v=-4*bending_k;
			else				break;
		}
		else
		{
			if(n==6 || n==7)	v=-4*bending_k;
			else				v=-2*bending_k;
		}		
		int oi, oj;			
			 if(n==6)	{oi=-1; oj=-1;}
		else if(n==7)	{oi= 1; oj= 1;}
		else if(n==8)	{oi=-2; oj= 0;}
		else if(n==9)	{oi= 2; oj= 0;}
		else if(n==10)	{oi= 0; oj=-2;}
		else if(n==11)	{oi= 0; oj= 2;}

		int nid=INDEX(i+oi, j+oj);
		float u[3];
		u[0]=X[id*3+0]-X[nid*3+0];
		u[1]=X[id*3+1]-X[nid*3+1];
		u[2]=X[id*3+2]-X[nid*3+2];

		//Bending
		f[0]-=v*u[0];
		f[1]-=v*u[1];
		f[2]-=v*u[2];
	}

	ret-=0.5f*X[id*3+0]*f[0];
	ret-=0.5f*X[id*3+1]*f[1];
	ret-=0.5f*X[id*3+2]*f[2];

	//ret+=0.5f*fixed_W[id*3+0]*(fixed_X[id*3+0]-X[id*3+0])*(fixed_X[id*3+0]-X[id*3+0]);
	//ret+=0.5f*fixed_W[id*3+1]*(fixed_X[id*3+1]-X[id*3+1])*(fixed_X[id*3+1]-X[id*3+1]);
	//ret+=0.5f*fixed_W[id*3+2]*(fixed_X[id*3+2]-X[id*3+2])*(fixed_X[id*3+2]-X[id*3+2]);	
	
	energy[id]=ret;	
}

///////////////////////////////////////////////////////////////////////////////////////////
//  Initialize_Kernel
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void Initialize_Kernel(
		  float* __restrict__ next_X,
	const float* __restrict__ X,
	const float* __restrict__ tilde_X,
	const char*  __restrict__ M,
	const int*   __restrict__ neighbor,
	const int*   __restrict__ neighbor_n,
	const float sigma,
	const float alpha,
	const float collision_k,
	const int ni, const int nj)
{
	int bi = blockIdx.x;
	int bj = blockIdx.y;
	int i = blockDim.x * bi + threadIdx.x;
	int j = blockDim.y * bj + threadIdx.y;
	if(i>=ni)									return;
	if(j>=nj)									return;
	int id=INDEX(i, j);
	if(M[id]==0)								return;

	next_X[id*3+0]=X[id*3+0];
	next_X[id*3+1]=X[id*3+1];
	next_X[id*3+2]=X[id*3+2];
	if(M[id]<0)									return;	

	float f[3]{};
	float d[3]{};	
	f[0]= sigma*(tilde_X[id*3+0]-X[id*3+0]);
	f[1]= sigma*(tilde_X[id*3+1]-X[id*3+1]);
	f[2]= sigma*(tilde_X[id*3+2]-X[id*3+2]);	
	d[0]=-sigma;
	d[1]=-sigma;
	d[2]=-sigma;	
	
	for(int n=0; n<MIN(16, neighbor_n[id]); n++)
	{		
		int nid=neighbor[id*16+n];
		float u[3];
		u[0]=X[id*3+0]-X[nid*3+0];
		u[1]=X[id*3+1]-X[nid*3+1];
		u[2]=X[id*3+2]-X[nid*3+2];		

		float v=0.0004f;
		float planar_k = collision_k;		//Young's modulus fix

		float dot_u2=DOT(u, u);
		if(dot_u2<1e-18f)	continue;
		float inv_m2=1.0f/dot_u2;
		float ratio=v*sqrtf(inv_m2);
		if(ratio>1)
		{
			f[0]-=planar_k*(1-ratio)*u[0];
			f[1]-=planar_k*(1-ratio)*u[1];
			f[2]-=planar_k*(1-ratio)*u[2];
			d[0]-=planar_k*(fmaxf(1-ratio, 0.0f)+ratio*u[0]*u[0]*inv_m2);
			d[1]-=planar_k*(fmaxf(1-ratio, 0.0f)+ratio*u[1]*u[1]*inv_m2);
			d[2]-=planar_k*(fmaxf(1-ratio, 0.0f)+ratio*u[2]*u[2]*inv_m2);
		}
	}

	if(d[0])	next_X[id*3+0]-=alpha*f[0]/d[0];
	if(d[1])	next_X[id*3+1]-=alpha*f[1]/d[1];
	if(d[2])	next_X[id*3+2]-=alpha*f[2]/d[2];
}


///////////////////////////////////////////////////////////////////////////////////////////
//  Update_Kernel
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void Update_Kernel(
		  float* __restrict__ next_X, 
	const float* __restrict__ prev_X, 
	const float* __restrict__ X,
	const float* __restrict__ tilde_X,
	const float* __restrict__ init_X,
	const float* __restrict__ init_XN,
	const float* __restrict__ proj_X,
	const float* __restrict__ P,
	const char*  __restrict__ M,
	const half2* __restrict__ spring_data, 
	const float* __restrict__ bend_data,
	const int*	 __restrict__ bend_ID,
		  int*	 __restrict__ block_state,
	const int*   __restrict__ neighbor,
	const int*   __restrict__ neighbor_n,
	const float spring_k,
	const float bending_k,
	const float air_k,
	const float body_k,
	const float alpha,
	const float omega,
	const int ni, const int nj, const int count, 
	const bool update_block_state,
		  float* __restrict__ block_energy=0)
{
	int bi = blockIdx.x;
	int bj = blockIdx.y;
	if(block_state[bi*(nj/BLOCK_SIZE)+bj]==0)	return;
	int i = blockDim.x * bi + threadIdx.x;
	int j = blockDim.y * bj + threadIdx.y;
	if(i>=ni)									return;
	if(j>=nj)									return;

	if(update_block_state)
	{
		__syncthreads();
		block_state[bi*(nj/BLOCK_SIZE)+bj]=0;
	}

	if(block_energy)
	{
		block_energy[bi*(nj/BLOCK_SIZE)+bj]=0;
	}

	__shared__ float X_data[3][BLOCK_SIZE+BLOCK_BUFF*2][BLOCK_SIZE+BLOCK_BUFF*2];
	/*if(i-2>=0 && j-2>=0)
	{
		X_data[threadIdx.x][threadIdx.y][0]=X[INDEX(i-2, j-2)*3+0];
		X_data[threadIdx.x][threadIdx.y][1]=X[INDEX(i-2, j-2)*3+1];
		X_data[threadIdx.x][threadIdx.y][2]=X[INDEX(i-2, j-2)*3+2];
	}

	if(i-2>=0 && j+2<nj)
	{
		X_data[threadIdx.x][threadIdx.y+4][0]=X[INDEX(i-2, j+2)*3+0];
		X_data[threadIdx.x][threadIdx.y+4][1]=X[INDEX(i-2, j+2)*3+1];
		X_data[threadIdx.x][threadIdx.y+4][2]=X[INDEX(i-2, j+2)*3+2];
	}

	if(i+2<ni && j-2>=0)
	{
		X_data[threadIdx.x+4][threadIdx.y][0]=X[INDEX(i+2, j-2)*3+0];
		X_data[threadIdx.x+4][threadIdx.y][1]=X[INDEX(i+2, j-2)*3+1];
		X_data[threadIdx.x+4][threadIdx.y][2]=X[INDEX(i+2, j-2)*3+2];
	}

	if(i+2<ni && j+2<nj)
	{
		X_data[threadIdx.x+4][threadIdx.y+4][0]=X[INDEX(i+2, j+2)*3+0];
		X_data[threadIdx.x+4][threadIdx.y+4][1]=X[INDEX(i+2, j+2)*3+1];
		X_data[threadIdx.x+4][threadIdx.y+4][2]=X[INDEX(i+2, j+2)*3+2];
	}*/

	//int N=(BLOCK_SIZE+4)*(BLOCK_SIZE+4)*4/(BLOCK_SIZE*BLOCK_SIZE);

	for(int n=0; n<8; n++)
	{
		int tid=n*BLOCK_SIZE*BLOCK_SIZE+threadIdx.x*BLOCK_SIZE+threadIdx.y;
		int dc=tid%3;
		int dj=(tid/3)%(BLOCK_SIZE+BLOCK_BUFF*2);
		int di=tid/((BLOCK_SIZE+BLOCK_BUFF*2)*3);
		if(di>=BLOCK_SIZE+BLOCK_BUFF*2)		break;

		//int dc= tid/((BLOCK_SIZE+BLOCK_BUFF*2)*(BLOCK_SIZE+BLOCK_BUFF*2));
		//if(dc>=3)			break;
		//int di=(tid%((BLOCK_SIZE+BLOCK_BUFF*2)*(BLOCK_SIZE+BLOCK_BUFF*2)))/(BLOCK_SIZE+BLOCK_BUFF*2);
		//int dj= tid% (BLOCK_SIZE+BLOCK_BUFF*2);
		int i=di+blockDim.x*bi-BLOCK_BUFF;
		int j=dj+blockDim.y*bj-BLOCK_BUFF;
		if(i<0 || i>=ni)	continue;
		if(j<0 || j>=nj)	continue;

		if(dc<3)	X_data[dc][di][dj]=X[INDEX(i, j)*3+dc];
		//if(dc==3)	X_data[dc][di][dj]=P[INDEX(i, j)];
	}

	__syncthreads();

	int id=INDEX(i, j);
	char mask=M[id];

	half s[6];	
	*(half2 *)(&s[0])=spring_data[0*ni*nj+id];
	*(half2 *)(&s[2])=spring_data[1*ni*nj+id];
	*(half2 *)(&s[4])=spring_data[2*ni*nj+id];
	
	float dx[3]{};
	float f0[3]{};
	for(int n=6; n<12; n++)
	{
		float v;//=dev_compact_bend_data[bid][n]*bending_k;			
		if((i+j)%2==0)
		{
			if(n==6 || n==7)	v=-4*bending_k;
			else				break;
		}
		else
		{
			if(n==6 || n==7)	v=-4*bending_k;
			else				v=-2*bending_k;
		}
		int oi, oj;	
			 if(n==6)	{oi=-1; oj=-1;}
		else if(n==7)	{oi= 1; oj= 1;}
		else if(n==8)	{oi=-2; oj= 0;}
		else if(n==9)	{oi= 2; oj= 0;}
		else if(n==10)	{oi= 0; oj=-2;}
		else if(n==11)	{oi= 0; oj= 2;}
		//Bending
		{
			f0[0]-=v*(-X_data[0][threadIdx.x+BLOCK_BUFF+oi][threadIdx.y+BLOCK_BUFF+oj]);
			f0[1]-=v*(-X_data[1][threadIdx.x+BLOCK_BUFF+oi][threadIdx.y+BLOCK_BUFF+oj]);
			f0[2]-=v*(-X_data[2][threadIdx.x+BLOCK_BUFF+oi][threadIdx.y+BLOCK_BUFF+oj]);
		}
	}
	
	//f0[0]+=sigma*tilde_X[id*3+0];
	//f0[1]+=sigma*tilde_X[id*3+1];
	//f0[2]+=sigma*tilde_X[id*3+2];
	

	float N[3];
	float dot0;
	if(mask==BODY_VALID_MASK)
	{
		N[0]=init_X[id*3+0]-proj_X[id*3+0];
		N[1]=init_X[id*3+1]-proj_X[id*3+1];
		N[2]=init_X[id*3+2]-proj_X[id*3+2];	
		float N_length=sqrtf(DOT(N, N));
		if(N_length)
		{
			N[0]/=N_length;
			N[1]/=N_length;
			N[2]/=N_length;
		}
		dot0=proj_X[id*3+0]*N[0]+proj_X[id*3+1]*N[1]+proj_X[id*3+2]*N[2];
	}

	float prev_x[3]{};
	float inner_omega	= 1.0f;
	float inner_rho		= 0.75;
		
	if(mask>0)
	for(int l=0; l<count; l++)
	{
		if(l==0)		inner_omega=1;
		else if(l==1)	inner_omega=2/(2-inner_rho*inner_rho);
		else			inner_omega=4/(4-inner_rho*inner_rho*inner_omega);

		float f[3]{};
		float d[3]{};
		float x[3];
		x[0]=X_data[0][threadIdx.x+BLOCK_BUFF][threadIdx.y+BLOCK_BUFF];
		x[1]=X_data[1][threadIdx.x+BLOCK_BUFF][threadIdx.y+BLOCK_BUFF];
		x[2]=X_data[2][threadIdx.x+BLOCK_BUFF][threadIdx.y+BLOCK_BUFF];		

		//deal with tilde_X
		//{
		//	f[0]-=sigma*x[0];
		//	f[1]-=sigma*x[1];
		//	f[2]-=sigma*x[2];
		//	d[0]-=sigma;
		//	d[1]-=sigma;
		//	d[2]-=sigma;
		//}

		//Deal with pressure
		if(P && P[id])
		{
			float inv_n=1/sqrtf(init_XN[id*3+0]*init_XN[id*3+0]+init_XN[id*3+1]*init_XN[id*3+1]+init_XN[id*3+2]*init_XN[id*3+2]);
			float mag=0.003f-(
				(x[0]-init_X[id*3+0])*init_XN[id*3+0]+
				(x[1]-init_X[id*3+1])*init_XN[id*3+1]+
				(x[2]-init_X[id*3+2])*init_XN[id*3+2])*inv_n;

			//f[0]+=P[id]*init_XN[id*3+0]*inv_n;
			//f[1]+=P[id]*init_XN[id*3+1]*inv_n;
			//f[2]+=P[id]*init_XN[id*3+2]*inv_n;

			//if(0)
			if(mag>0)
			{
			//	f[0]+=P[id]*mag*init_XN[id*3+0]*inv_n*100000;
			//	f[1]+=P[id]*mag*init_XN[id*3+1]*inv_n*100000;
			//	f[2]+=P[id]*mag*init_XN[id*3+2]*inv_n*100000;
			}
		}

		float last_u[3]{};
		if(i-1>=0 && j+1<nj)
		{
			last_u[0]=x[0]-X_data[0][threadIdx.x+BLOCK_BUFF-1][threadIdx.y+BLOCK_BUFF+1];
			last_u[1]=x[1]-X_data[1][threadIdx.x+BLOCK_BUFF-1][threadIdx.y+BLOCK_BUFF+1];
			last_u[2]=x[2]-X_data[2][threadIdx.x+BLOCK_BUFF-1][threadIdx.y+BLOCK_BUFF+1];
		}

		for(int n=0; n<6; n++)
		{
			int oi, oj;
				 if(n==0)	{oi=-1; oj= 0;}
			else if(n==1)	{oi= 0; oj=-1;}
			else if(n==2)	{oi= 1; oj=-1;}
			else if(n==3)	{oi= 1; oj= 0;}
			else if(n==4)	{oi= 0; oj= 1;}
			else if(n==5)	{oi=-1; oj= 1;}
			float u[3];
			u[0]=x[0]-X_data[0][threadIdx.x+BLOCK_BUFF+oi][threadIdx.y+BLOCK_BUFF+oj];
			u[1]=x[1]-X_data[1][threadIdx.x+BLOCK_BUFF+oi][threadIdx.y+BLOCK_BUFF+oj];
			u[2]=x[2]-X_data[2][threadIdx.x+BLOCK_BUFF+oi][threadIdx.y+BLOCK_BUFF+oj];

			//spring		
			{
				float N[3];
				CROSS(last_u, u, N);
				if(P[id])
				{
					f[0]-=N[0]*750000000;
					f[1]-=N[1]*750000000;
					f[2]-=N[2]*750000000;
				}
				last_u[0]=u[0];
				last_u[1]=u[1];
				last_u[2]=u[2];

				float planar_k = spring_k/(float)s[n];		//Young's modulus fix
				float inv_m2=1.0f/DOT(u, u);
				float ratio=(float)s[n]*sqrtf(inv_m2);

				//if(ratio<1 || ratio>1.0f/0.99f)
				{
					//if(ratio>1.0f/0.99f)	ratio*=0.99f;

					f[0]-=planar_k*(1-ratio)*u[0];
					f[1]-=planar_k*(1-ratio)*u[1];
					f[2]-=planar_k*(1-ratio)*u[2];
					d[0]-=planar_k*(fmaxf(1-ratio, 0.0f)+ratio*u[0]*u[0]*inv_m2);
					d[1]-=planar_k*(fmaxf(1-ratio, 0.0f)+ratio*u[1]*u[1]*inv_m2);
					d[2]-=planar_k*(fmaxf(1-ratio, 0.0f)+ratio*u[2]*u[2]*inv_m2);
				}
			}
			//Bending
			float v;
			if(n==2 || n==5)	v=-4*bending_k;
			else				v=12*bending_k;
			f[0]-=v*u[0];
			f[1]-=v*u[1];
			f[2]-=v*u[2];
		}

		///for(int n=6; n<12; n++)
		//{
		//	float v;//=dev_compact_bend_data[bid][n]*bending_k;			
		//	if((i+j)%2==0)
		//	{
		//		if(n==6 || n==7)	v=-4*bending_k;
		//		else				break;
		//	}
		//	else
		//	{
		//		if(n==6 || n==7)	v=-4*bending_k;
		//		else				v=-2*bending_k;
		//	}
		//	int oi, oj;			
		//		 if(n==6)	{oi=-1; oj=-1;}
		//	else if(n==7)	{oi= 1; oj= 1;}
		//	else if(n==8)	{oi=-2; oj= 0;}
		//	else if(n==9)	{oi= 2; oj= 0;}
		//	else if(n==10)	{oi= 0; oj=-2;}
		//	else if(n==11)	{oi= 0; oj= 2;}
		//	//Bending
		//	f[0]-=v*(x[0]-X_data[0][threadIdx.x+BLOCK_BUFF+oi][threadIdx.y+BLOCK_BUFF+oj]);
		//	f[1]-=v*(x[1]-X_data[1][threadIdx.x+BLOCK_BUFF+oi][threadIdx.y+BLOCK_BUFF+oj]);
		//	f[2]-=v*(x[2]-X_data[2][threadIdx.x+BLOCK_BUFF+oi][threadIdx.y+BLOCK_BUFF+oj]);
		//}

		if((i+j)%2==0)
		{
			f[0]+=f0[0]+8*bending_k*x[0];
			f[1]+=f0[1]+8*bending_k*x[1];
			f[2]+=f0[2]+8*bending_k*x[2];
			d[0]-=32*bending_k;
			d[1]-=32*bending_k;
			d[2]-=32*bending_k;
		}
		else
		{
			f[0]+=f0[0]+16*bending_k*x[0];
			f[1]+=f0[1]+16*bending_k*x[1];
			f[2]+=f0[2]+16*bending_k*x[2];
			d[0]-=24*bending_k;
			d[1]-=24*bending_k;
			d[2]-=24*bending_k;
		}

		for(int n=0; n<MIN(16, neighbor_n[id]); n++)
		{
			float u[3];
			
			//int ii=neighbor[id*16+n]/nj - blockDim.x * bi;
			//int jj=neighbor[id*16+n]%nj - blockDim.y * bj;
			//if(ii>=-BLOCK_BUFF && ii<BLOCK_SIZE+BLOCK_BUFF && jj>=-BLOCK_BUFF && jj<BLOCK_SIZE+BLOCK_BUFF)
			//{
			//	u[0]=x[0]-X_data[0][BLOCK_BUFF+ii][BLOCK_BUFF+jj];
			//	u[1]=x[1]-X_data[1][BLOCK_BUFF+ii][BLOCK_BUFF+jj];
			//	u[2]=x[2]-X_data[2][BLOCK_BUFF+ii][BLOCK_BUFF+jj];
			//}
			//else
			{
				int nid=neighbor[id*16+n];
				u[0]=x[0]-X[nid*3+0];
				u[1]=x[1]-X[nid*3+1];
				u[2]=x[2]-X[nid*3+2];
			}

			float v=0.0004f;
			float planar_k = 1e9f;		//Young's modulus fix
			float inv_m2=1.0f/DOT(u, u);
			float ratio=v*sqrtf(inv_m2);
			if(ratio>1)
			{
				f[0]-=planar_k*(1-ratio)*u[0];
				f[1]-=planar_k*(1-ratio)*u[1];
				f[2]-=planar_k*(1-ratio)*u[2];
				d[0]-=planar_k*(fmaxf(1-ratio, 0.0f)+ratio*u[0]*u[0]*inv_m2);
				d[1]-=planar_k*(fmaxf(1-ratio, 0.0f)+ratio*u[1]*u[1]*inv_m2);
				d[2]-=planar_k*(fmaxf(1-ratio, 0.0f)+ratio*u[2]*u[2]*inv_m2);
			}
		}
		
		if(mask==BODY_VALID_MASK)
		{
			float dot=DOT(x, N)-dot0;
			if(dot<0)
			{
				f[0]-=body_k*dot*N[0];
				f[1]-=body_k*dot*N[1];
				f[2]-=body_k*dot*N[2];
				d[0]-=body_k*N[0]*N[0];
				d[1]-=body_k*N[1]*N[1];
				d[2]-=body_k*N[2]*N[2];
			}
		}

		if(d[0])
		{
			 x[0]-=alpha*f[0]/d[0];
			dx[0]-=alpha*f[0]/d[0];
		}
		if(d[1])
		{
			 x[1]-=alpha*f[1]/d[1];
			dx[1]-=alpha*f[1]/d[1];
		}
		if(d[2])
		{
			 x[2]-=alpha*f[2]/d[2];
			dx[2]-=alpha*f[2]/d[2];
		}
		if(inner_omega!=1)
		{
			x[0]+=(inner_omega-1)*(x[0]-prev_x[0]);
			x[1]+=(inner_omega-1)*(x[1]-prev_x[1]);
			x[2]+=(inner_omega-1)*(x[2]-prev_x[2]);
		}
		prev_x[0]=X_data[0][threadIdx.x+BLOCK_BUFF][threadIdx.y+BLOCK_BUFF];
		prev_x[1]=X_data[1][threadIdx.x+BLOCK_BUFF][threadIdx.y+BLOCK_BUFF];
		prev_x[2]=X_data[2][threadIdx.x+BLOCK_BUFF][threadIdx.y+BLOCK_BUFF];
		X_data[0][threadIdx.x+BLOCK_BUFF][threadIdx.y+BLOCK_BUFF]=x[0];
		X_data[1][threadIdx.x+BLOCK_BUFF][threadIdx.y+BLOCK_BUFF]=x[1];
		X_data[2][threadIdx.x+BLOCK_BUFF][threadIdx.y+BLOCK_BUFF]=x[2];

		__syncthreads();
	}

	if(update_block_state)
	{
		if(fabsf(dx[0])>5e-7f || fabsf(dx[1])>5e-7f || fabsf(dx[2])>5e-7f)
			block_state[bi*(nj/BLOCK_SIZE)+bj]=1;		
	}
	
	float x[3];
	x[0]=X_data[0][threadIdx.x+BLOCK_BUFF][threadIdx.y+BLOCK_BUFF];
	x[1]=X_data[1][threadIdx.x+BLOCK_BUFF][threadIdx.y+BLOCK_BUFF];
	x[2]=X_data[2][threadIdx.x+BLOCK_BUFF][threadIdx.y+BLOCK_BUFF];	
	if(omega!=1)
	{
		x[0]+=(omega-1)*(x[0]-prev_X[id*3+0]);
		x[1]+=(omega-1)*(x[1]-prev_X[id*3+1]);
		x[2]+=(omega-1)*(x[2]-prev_X[id*3+2]);
	}
	next_X[id*3+0]=x[0];
	next_X[id*3+1]=x[1];
	next_X[id*3+2]=x[2];

	if(block_energy)
	{
		next_X[id*3+0]-=X[id*3+0];
		next_X[id*3+1]-=X[id*3+1];
		next_X[id*3+2]-=X[id*3+2];

		float e=next_X[id*3+0]*next_X[id*3+0]+next_X[id*3+1]*next_X[id*3+1]+next_X[id*3+2]*next_X[id*3+2];

		atomicAdd(&block_energy[bi*(nj/BLOCK_SIZE)+bj], e);

		//energy[id]=next_X[id*3+0]*next_X[id*3+0]+next_X[id*3+1]*next_X[id*3+1]+next_X[id*3+2]*next_X[id*3+2];
	}
}


///////////////////////////////////////////////////////////////////////////////////////////
//  Cblock_Center_Kernel
//	This kernel computes the center of each collision block.
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void Cblock_Center_Kernel(
		  float* __restrict__ cblock_center,
	const int*	 __restrict__ cblock_state,
	const float* __restrict__ X,
	const char*  __restrict__ M,
	const int s,
	const int ni, const int nj)
{
	int i = blockDim.x * blockIdx.x + threadIdx.x;
	int j = blockDim.y * blockIdx.y + threadIdx.y;
	if(i>=ni)					return;
	if(j>=nj)					return;
	int cbid=INDEX(i, j);
	if(cblock_state[cbid]==0)	return;
	
	float c[4]{};
	for(int ii=i*s; ii<i*s+s; ii++)
	for(int jj=j*s; jj<j*s+s; jj++)
	{
		int cid=ii*nj*s+jj;
		if(M[cid]==EMPTY_MASK)			continue;
		c[0]+=X[cid*3+0];
		c[1]+=X[cid*3+1];
		c[2]+=X[cid*3+2];
		c[3]+=1;
	}
	if(c[3])
	{
		c[0]/=c[3];
		c[1]/=c[3];
		c[2]/=c[3];
	}
	cblock_center[cbid*3+0]=c[0];
	cblock_center[cbid*3+1]=c[1];
	cblock_center[cbid*3+2]=c[2];
}

///////////////////////////////////////////////////////////////////////////////////////////
//  Long_Range_Culling_Kernel
//	This kernel performs long-range culling between two collision blocks.  The long range 
//	here is defined as 8 blocks away, but not within 1 block distance.  The culling uses
//	the previously calculated block center and writes the surviving block pairs into "pair".
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void Long_Range_Culling_Kernel(
	const float* __restrict__ cblock_center,
	const int*	 __restrict__ cblock_state,
		  int*	 __restrict__ pair,
		  int*   __restrict__ pair_n,
	const int max_pair_number,
	const float gap2,
	const int ni, const int nj)
{
	int i = blockDim.x * blockIdx.x + threadIdx.x;
	int j = blockDim.y * blockIdx.y + threadIdx.y;
	if(i>=ni)						return;
	if(j>=nj)						return;
	int cbid0=INDEX(i, j);
	if(cblock_state[cbid0]==0)		return;

	float c[3];
	c[0]=cblock_center[cbid0*3+0];
	c[1]=cblock_center[cbid0*3+1];
	c[2]=cblock_center[cbid0*3+2];

	for(int ii=-8; ii<=8; ii++)
	for(int jj=-8; jj<=8; jj++)
	{
		if(abs(ii)<=1 && abs(jj)<=1)		continue;
		if(i+ii<0 || i+ii>=ni)				continue;
		if(j+jj<0 || j+jj>=nj)				continue;
		int cbid1=INDEX(i+ii, j+jj);
		if(cbid1>cbid0)						continue;
		if(cblock_state[cbid1]==0)			continue;

		float u[3];
		u[0]=c[0]-cblock_center[cbid1*3+0];
		u[1]=c[1]-cblock_center[cbid1*3+1];
		u[2]=c[2]-cblock_center[cbid1*3+2];
		if(DOT(u, u)<gap2)
		{
			int ptr=atomicAdd(pair_n, 1);
			if(ptr<max_pair_number)
			{
				pair[ptr*2+0]=cbid0;
				pair[ptr*2+1]=cbid1;
				//printf("ok %d: %d, %d: %d, %d (%f)\n", ptr, ii, jj, i, j, sqrtf(dist)/0.000371);
			}
		}		
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
//  Long_Range_Search_Kernel
//	This kernel performs long-range neighbor search between two collision blocks (cblock),
//	provided as "pair".  Each block is corresponding to a pair and its fixed 256 thresholds
//	cover the 4*4*4*4 node combinations.
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void Long_Range_Search_Kernel(
	const float* __restrict__ X,
	const char*  __restrict__ M,
	const int*	 __restrict__ pair,
	const int*	 __restrict__ pair_n,
	const int max_pair_number,
		  int*	 __restrict__ neighbor,
		  int*	 __restrict__ neighbor_n,
	const float gap2,
	const int ni, const int nj)
{
	int N = MIN(pair_n[0], max_pair_number);

	for(int p=blockIdx.x; p<N; p+=gridDim.x)
	{
		//Calculate the node indices (id0 and id1).
		int i0=(pair[p*2+0]/(nj/4))*4;
		int j0=(pair[p*2+0]%(nj/4))*4;
		int i1=(pair[p*2+1]/(nj/4))*4;
		int j1=(pair[p*2+1]%(nj/4))*4;
		i0+= threadIdx.x/64;
		j0+=(threadIdx.x%64)/16;
		i1+=(threadIdx.x%16)/4;
		j1+= threadIdx.x%4;
		int id0=INDEX(i0, j0);
		int id1=INDEX(i1, j1);
		
		float u[3];
		u[0]=X[id1*3+0]-X[id0*3+0];
		u[1]=X[id1*3+1]-X[id0*3+1];
		u[2]=X[id1*3+2]-X[id0*3+2];
		if(DOT(u, u)<gap2)
		{
			int ptr;
			if(M[id1]>0)
			{
				ptr=atomicAdd(&neighbor_n[id1], 1);
				if(ptr<16)	neighbor[id1*16+ptr]=id0;
			}
			if(M[id0]>0)
			{
				ptr=atomicAdd(&neighbor_n[id0], 1);
				if(ptr<16)	neighbor[id0*16+ptr]=id1;
			}
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
//  Short_Range_Search_Kernel
//	This kernel performs short-range neighbor search within 1 collision block distance.
//	It tests every node with the nodes in the five collision blocsk around it.
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void Short_Range_Search_Kernel(
	const float* __restrict__ X,
	const char*  __restrict__ M,
	const int*   __restrict__ cblock_state,
		  int*	 __restrict__ neighbor,
		  int*	 __restrict__ neighbor_n,
	const float gap2,
	const int ni, const int nj)
{
	int i0 = blockDim.x * blockIdx.x + threadIdx.x;
	int j0 = blockDim.y * blockIdx.y + threadIdx.y;
	if(i0>=ni)									return;
	if(j0>=nj)									return;
	if(cblock_state[(i0/4)*(nj/4)+(j0/4)]==0)	return;
	int id0=INDEX(i0, j0);
	if(M[id0]==EMPTY_MASK)						return;
	
	float x[3];
	x[0]=X[id0*3+0];
	x[1]=X[id0*3+1];
	x[2]=X[id0*3+2];

	for(int ii=0; ii<4; ii++)
	for(int jj=0; jj<4; jj++)
	for(int b=0; b<5; b++)
	{
		int i1, j1;
		i1=(i0/4+b/3-1)*4+ii;
		j1=(j0/4+b%3-1)*4+jj;
		if(abs(i0-i1)<=1 && abs(j0-j1)<=1)	continue;
		int id1=INDEX(i1, j1);
		if(b==4 && id0<id1)					continue;
				
		float u[3];
		u[0]=x[0]-X[id1*3+0];
		u[1]=x[1]-X[id1*3+1];
		u[2]=x[2]-X[id1*3+2];
		if(DOT(u, u)<gap2)
		{
			int ptr;
			if(M[id0]>0)
			{
				ptr=atomicAdd(&neighbor_n[id0], 1);
				if(ptr<16)	neighbor[id0*16+ptr]=id1;
			}
			if(M[id1]>0)
			{
				ptr=atomicAdd(&neighbor_n[id1], 1);
				if(ptr<16)	neighbor[id1*16+ptr]=id0;
			}
		}
	}
}


///////////////////////////////////////////////////////////////////////////////////////////
//  Test_Kernel2
///////////////////////////////////////////////////////////////////////////////////////////
/*__global__ void Test_Kernel2(
	const float* __restrict__ X,
	const char*  __restrict__ M,
		  int*   __restrict__ neighbor,
		  int*   __restrict__ neighbor_n,	
		  int*	 __restrict__ block_map,
	const int ni, const int nj)
{
	int bi = blockIdx.x;
	int bj = blockIdx.y;
	int i = blockDim.x * bi + threadIdx.x;
	int j = blockDim.y * bj + threadIdx.y;
	if(i>=ni)								return;
	if(j>=nj)								return;
	int id=INDEX(i, j);	
	if(M[id]<=0)							return;

	float x[3];
	x[0]=X[id*3+0];
	x[1]=X[id*3+1];
	x[2]=X[id*3+2];

	float gap=0.0004f*0.0004f;

	int n=0;
	for(int ii=(i/4)*4-4; ii<(i/4)*4+8; ii++)
	for(int jj=(j/4)*4-4; jj<(j/4)*4+8; jj++)
	{	
		if(abs(ii-i)<=1)		continue;
		if(abs(jj-j)<=1)		continue;

		float u[3];
		u[0]=x[0]-X[INDEX(ii, jj)*3+0];
		u[1]=x[1]-X[INDEX(ii, jj)*3+1];
		u[2]=x[2]-X[INDEX(ii, jj)*3+2];
		
		if(DOT(u, u)<gap)
		{
			neighbor[id*16+n++]=INDEX(ii, jj);
		}
	}
	neighbor_n[id]=n;
}*/


///////////////////////////////////////////////////////////////////////////////////////////
//  Spring_Length_Kernel
///////////////////////////////////////////////////////////////////////////////////////////
__device__ 
float dev_Get_Spring_Length(
	int i, int j, int oi, int oj, 
	const float X[], 
	const float G[], 
	const char  M[], 
	const int ni, const int nj, const float h)
{
	if(i<0 || i>=ni)				return;
	if(j<0 || j>=nj)				return;
	if(i+oi<0 || i+oi>=ni)			return;
	if(j+oj<0 || j+oj>=nj)			return;
	int  id=INDEX(i, j);
	int nid=INDEX(i+oi, j+oj);
	if(M[id]==EMPTY_MASK)			return;
	if(M[nid]==EMPTY_MASK)			return;
	float w=G[id*4+2]+G[nid*4+2];
	if(w==0)						return;

	float s[4];
	s[0]=(G[id*4+0]+G[nid*4+0])/w;
	s[1]=(G[id*4+1]+G[nid*4+1])/w;
	s[2]=s[1];
	s[3]=(G[id*4+3]+G[nid*4+3])/w;


	float rate=
		sqrtf(	(X[id*3+0]-X[nid*3+0])*(X[id*3+0]-X[nid*3+0])+
				(X[id*3+1]-X[nid*3+1])*(X[id*3+1]-X[nid*3+1])+
				(X[id*3+2]-X[nid*3+2])*(X[id*3+2]-X[nid*3+2]))/(sqrtf(oi*oi+oj*oj)*h);

	return sqrtf((s[0]*oi+s[1]*oj)*(s[0]*oi+s[1]*oj)+(s[2]*oi+s[3]*oj)*(s[2]*oi+s[3]*oj))*h*rate;
	//return sqrtf((s[0]*oi+s[1]*oj)*(s[0]*oi+s[1]*oj)+(s[2]*oi+s[3]*oj)*(s[2]*oi+s[3]*oj))*h;
}

///////////////////////////////////////////////////////////////////////////////////////////
//  Spring_Length_Kernel
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void Spring_Length_Kernel(
	const float* __restrict__ X,
	const float* __restrict__ G,
	const char*  __restrict__ M,
		  half2* __restrict__ spring_data, 
	const float h, const int ni, const int nj)
{
	int bi = blockIdx.x;
	int bj = blockIdx.y;
	int i = blockDim.x * bi + threadIdx.x;
	int j = blockDim.y * bj + threadIdx.y;
	if(i<0 || i>=ni)				return;
	if(j<0 || j>=nj)				return;	
	int  id=INDEX(i, j);	
	if(M[id]==EMPTY_MASK)			return;

	spring_data[0*ni*nj+id].x=dev_Get_Spring_Length(i, j, -1,  0, X, G, M, ni, nj, h);
	spring_data[0*ni*nj+id].y=dev_Get_Spring_Length(i, j,  0, -1, X, G, M, ni, nj, h);
	spring_data[1*ni*nj+id].x=dev_Get_Spring_Length(i, j,  1, -1, X, G, M, ni, nj, h);
	spring_data[1*ni*nj+id].y=dev_Get_Spring_Length(i, j,  1,  0, X, G, M, ni, nj, h);
	spring_data[2*ni*nj+id].x=dev_Get_Spring_Length(i, j,  0,  1, X, G, M, ni, nj, h);
	spring_data[2*ni*nj+id].y=dev_Get_Spring_Length(i, j, -1,  1, X, G, M, ni, nj, h);
}

///////////////////////////////////////////////////////////////////////////////////////////
//  G_Smoothing_Kernel
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void G_Smoothing_Kernel(
		  float* __restrict__ X,
	const float* __restrict__ X0,
	const float* __restrict__ X1,
	const float* __restrict__ X2,
	const float* __restrict__ G,
	const char*  __restrict__ M,
	const int ni, const int nj)
{
	int bi = blockIdx.x;
	int bj = blockIdx.y;
	int i = blockDim.x * bi + threadIdx.x;
	int j = blockDim.y * bj + threadIdx.y;
	if(i<0 || i>=ni)						return;
	if(j<0 || j>=nj)						return;
	int id=INDEX(i, j);
	if(M[id]==EMPTY_MASK)					return;
	/*if(G[id*4+2]!=1)
	{
		X[id*3+0]=X0[id*3+0];
		X[id*3+1]=X0[id*3+1];
		X[id*3+2]=X0[id*3+2];
	}
	else*/
	{
		X[id*3+0]=(X0[id*3+0]*3+X1[id*3+0]+X2[id*3+0])/5.0f;
		X[id*3+1]=(X0[id*3+1]*3+X1[id*3+1]+X2[id*3+1])/5.0f;
		X[id*3+2]=(X0[id*3+2]*3+X1[id*3+2]+X2[id*3+2])/5.0f;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
//  Select_Kernel
///////////////////////////////////////////////////////////////////////////////////////////
__global__ void Select_Kernel(
	const float* __restrict__ X,
	const char*  __restrict__ M,
		  int*   __restrict__ selection, 
	const int selection_length, 
	const float px, const float py,	const float pz,
	const float dx,	const float dy, const float dz,
	const int ni,	const int nj,	const float h)
{
	int bi = blockIdx.x;
	int bj = blockIdx.y;
	int i = blockDim.x * bi + threadIdx.x;
	int j = blockDim.y * bj + threadIdx.y;
	if(i<0 || i>=ni)						return;
	if(j<0 || j>=nj)						return;
	int id=INDEX(i, j);
	if(M[id]==EMPTY_MASK)					return;

	float v[3];
	v[0]=X[id*3+0]-px;
	v[1]=X[id*3+1]-py;
	v[2]=X[id*3+2]-pz;
	float t=v[0]*dx+v[1]*dy+v[2]*dz;
	if(t<0)						return;
	float d=(v[0]-t*dx)*(v[0]-t*dx)+
			(v[1]-t*dy)*(v[1]-t*dy)+
			(v[2]-t*dz)*(v[2]-t*dz);
	if(d>h*h*9)					return;


	int addr=atomicAdd(&selection[0], 1)+1;
	if(addr<selection_length)	selection[addr]=id;	
}

///////////////////////////////////////////////////////////////////////////////////////////
//  class CUDA_SIM_TEXTURE 
///////////////////////////////////////////////////////////////////////////////////////////
template <class TYPE>
class CUDA_SIM_TEXTURE: public SIM_TEXTURE<TYPE>
{
public:
	int		numSMs;
	int		numThs;

	TYPE*	dev_llast_X			= 0;
	TYPE*	dev_last_X			= 0;
	TYPE*	dev_tilde_X			= 0;
	TYPE*	dev_X				= 0;	//Vertex
	TYPE*	dev_R				= 0;	//Vertex reference
	TYPE*	dev_C				= 0;	//Color
	TYPE*	dev_XN				= 0;	//Vertex normal
	TYPE*	dev_XG				= 0;	//Vertex tangent	
	TYPE*	dev_init_X			= 0;	//Initial vertex
	TYPE*	dev_init_XN			= 0;	//Initial vertex normal
	TYPE*	dev_init_XG			= 0;	//Initial vertex normal
	TYPE*	dev_coord			= 0;
	TYPE*	dev_proj_X			= 0;	//Projected vertex to body
	int*	dev_T				= 0;	//Triangle
	TYPE*	dev_P				= 0;	//Pressure
	char*	dev_M				= 0;	//Mask
	TYPE*	dev_energy			= 0;
	TYPE*	dev_block_energy	= 0;

	TYPE*	dev_prev_X			= 0;
	TYPE*	dev_next_X			= 0;

	TYPE*	dev_G				= 0;
	half2*	dev_spring_data		= 0;
	int*	dev_bend_ID			= 0;
	TYPE*	dev_bend_data		= 0;
	int*	dev_block_state0	= 0;
	int*	dev_block_state1	= 0;

	//Data for making fast CUDA-based selection.
	int*	dev_selection		= 0;

	int*	dev_cblock_state	= 0;
	TYPE*	dev_cblock_center	= 0;
	int*	dev_pair			= 0;
	int*	dev_pair_n			= 0;
	int		max_pair_number		= 65536*2;

	int*	dev_neighbor		= 0;
	int*	dev_neighbor_n		= 0;

	bool	update_cuda_graph	= true;
	cudaGraph_t			graph	= 0;
	cudaGraphExec_t		si		= 0;
	cudaStream_t		st		= 0;

	CUDA_LEVEL_SET<TYPE>*	set = 0;

///////////////////////////////////////////////////////////////////////////////////////////
//  Constructor and Deconstructor
///////////////////////////////////////////////////////////////////////////////////////////
	CUDA_SIM_TEXTURE()
	{}

	~CUDA_SIM_TEXTURE()
	{
		Free_GPU_Memory();
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Free_GPU_Memory
///////////////////////////////////////////////////////////////////////////////////////////
	void Free_GPU_Memory()
	{
		cudaFree(dev_llast_X);
		cudaFree(dev_last_X);
		cudaFree(dev_tilde_X);
		cudaFree(dev_X);
		cudaFree(dev_R);
		cudaFree(dev_C);
		cudaFree(dev_XN);
		cudaFree(dev_init_X);
		cudaFree(dev_init_XN);
		cudaFree(dev_init_XG);
		cudaFree(dev_coord);
		cudaFree(dev_proj_X);
		cudaFree(dev_XG);
		cudaFree(dev_T);
		cudaFree(dev_P);
		cudaFree(dev_M);
		cudaFree(dev_energy);
		cudaFree(dev_block_energy);
		cudaFree(dev_prev_X);
		cudaFree(dev_next_X);
		cudaFree(dev_G);
		cudaFree(dev_spring_data);
		cudaFree(dev_bend_ID);
		cudaFree(dev_block_state0);
		cudaFree(dev_block_state1);

		cudaFree(dev_bend_data);
		cudaFree(dev_selection);

		cudaFree(dev_cblock_state);
		cudaFree(dev_cblock_center);
		cudaFree(dev_pair);
		cudaFree(dev_pair_n);

		cudaFree(dev_neighbor);
		cudaFree(dev_neighbor_n);

		if(set)		delete set;
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Allocate_Memory
///////////////////////////////////////////////////////////////////////////////////////////	
	void Allocate_Memory(int _ni, int _nj)
	{	
		cudaDeviceGetAttribute(&numSMs, cudaDevAttrMultiProcessorCount, 0);
		cudaDeviceGetAttribute(&numThs, cudaDevAttrMaxThreadsPerMultiProcessor, 0);

		SIM_TEXTURE<TYPE>::Allocate_Memory(_ni, _nj);

		Free_GPU_Memory();
		cudaMalloc((void**)&dev_llast_X,		sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_last_X,			sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_tilde_X,		sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_X,				sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_R,				sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_C,				sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_XN,				sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_init_X,			sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_init_XN,		sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_init_XG,		sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_coord,			sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_proj_X,			sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_XG,				sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_T,				sizeof(int )*t_number*3);
		cudaMalloc((void**)&dev_P,				sizeof(TYPE)*number    );
		cudaMalloc((void**)&dev_M,				sizeof(char)*number    );
		cudaMalloc((void**)&dev_energy,			sizeof(TYPE)*number    );
		cudaMalloc((void**)&dev_block_energy,	sizeof(TYPE)*number/( BLOCK_SIZE* BLOCK_SIZE));
		cudaMalloc((void**)&dev_prev_X,			sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_next_X,			sizeof(TYPE)*number*3  );
		cudaMalloc((void**)&dev_G,				sizeof(TYPE)*number*4  );
		cudaMalloc((void**)&dev_spring_data,	sizeof(half2)*number*3 );
		cudaMalloc((void**)&dev_bend_ID,		sizeof(int )*number    );
		cudaMalloc((void**)&dev_bend_data,		sizeof(int )*number*12 );
		cudaMalloc((void**)&dev_block_state0,	sizeof(int )*number/( BLOCK_SIZE* BLOCK_SIZE));
		cudaMalloc((void**)&dev_block_state1,	sizeof(int )*number/( BLOCK_SIZE* BLOCK_SIZE));

		cudaMalloc((void**)&dev_selection,		sizeof(int )*selection_length);
		cudaMalloc((void**)&dev_cblock_state,	sizeof(int )*number/(CBLOCK_SIZE*CBLOCK_SIZE));
		cudaMalloc((void**)&dev_cblock_center,	sizeof(TYPE)*number*3/16);

		cudaMalloc((void**)&dev_pair,			sizeof(int )*(max_pair_number+1)*2);
		cudaMalloc((void**)&dev_pair_n,			sizeof(int ));

		cudaMalloc((void**)&dev_neighbor,		sizeof(int )*number*16 );
		cudaMalloc((void**)&dev_neighbor_n,		sizeof(int )*number);

		cudaMemset(dev_coord, 0, sizeof(TYPE)*number*3);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Initialize
///////////////////////////////////////////////////////////////////////////////////////////	
	void Initialize(TYPE _h, BASIC_MESH<TYPE> &mesh)
	{
		//TIMER timer;
		h = _h;
		Initialize_Arrays();
		Set_Mask_from_Mesh(mesh);
		//printf("A: %f\n", timer.Get_Time());
		Initialize_Mesh_Boundary(mesh);
		//printf("B: %f\n", timer.Get_Time());


		//Spring_Length();
		//Bending_Data();

		//printf("D: %f\n", timer.Get_Time());

		cudaMemcpy(dev_X,				X,				sizeof(TYPE)*number*3,		cudaMemcpyHostToDevice);
		cudaMemcpy(dev_R,				R,				sizeof(TYPE)*number*3,		cudaMemcpyHostToDevice);
		cudaMemcpy(dev_C,				C,				sizeof(TYPE)*number*3,		cudaMemcpyHostToDevice);
		cudaMemcpy(dev_T,				T,				sizeof(int )*t_number*3,	cudaMemcpyHostToDevice);
		cudaMemcpy(dev_P,				P,				sizeof(TYPE)*number,		cudaMemcpyHostToDevice);
		cudaMemcpy(dev_M,				M,				sizeof(char)*number,		cudaMemcpyHostToDevice);
		cudaMemcpy(dev_G,				G,				sizeof(TYPE)*number*4,		cudaMemcpyHostToDevice);
		//cudaMemcpy(dev_spring_data,	spring_data,	sizeof(TYPE)*number*6,		cudaMemcpyHostToDevice);
		//cudaMemcpy(dev_bend_data,		bend_data,		sizeof(TYPE)*number*12,		cudaMemcpyHostToDevice);

		//cudaMemcpy(dev_bend_ID,			bend_ID,		sizeof(int )*number,		cudaMemcpyHostToDevice);		
		cudaMemcpy(dev_block_state0,	block_state,	sizeof(int )*number/( BLOCK_SIZE* BLOCK_SIZE),	cudaMemcpyHostToDevice);
		cudaMemcpy(dev_block_state1,	block_state,	sizeof(int )*number/( BLOCK_SIZE* BLOCK_SIZE),	cudaMemcpyHostToDevice);
		cudaMemcpy(dev_cblock_state,	cblock_state,	sizeof(int )*number/(CBLOCK_SIZE*CBLOCK_SIZE),	cudaMemcpyHostToDevice);
		//cudaMemcpyToSymbol(dev_compact_bend_data, compact_bend_data, sizeof(TYPE)*256*12);

		CUDA_Spring_Length();
		CUDA_Build_XN();
		cudaMemcpy(dev_init_X,			dev_X,			sizeof(TYPE)*number*3,		cudaMemcpyDeviceToDevice);
		cudaMemcpy(dev_init_XN,			dev_XN,			sizeof(TYPE)*number*3,		cudaMemcpyDeviceToDevice);
		cudaMemcpy(dev_init_XG,			dev_XG,			sizeof(TYPE)*number*3,		cudaMemcpyDeviceToDevice);

		//Additional stuffs here.
		//cudaMemcpy(XN,					dev_XN,			sizeof(TYPE)*number*3,		cudaMemcpyDeviceToHost);
		//cudaMemcpy(XG,					dev_XG,			sizeof(TYPE)*number*3,		cudaMemcpyDeviceToHost);

			//printf("E: %f\n", timer.Get_Time());
	}


///////////////////////////////////////////////////////////////////////////////////////////
//  Initialize_Phi
///////////////////////////////////////////////////////////////////////////////////////////
	void Initialize_Phi(const float X[], const int number, const float h, const float gap_x = 0.2f, const float gap_y = 0.2f, const float gap_z = 0.2f, const float offset = -1.25f)
	{
		set= new CUDA_LEVEL_SET<TYPE>;
		set->Initialize(X, number, h, gap_x, gap_y, gap_z, offset);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Restart_Batch
///////////////////////////////////////////////////////////////////////////////////////////	
	void Restart_Batch()
	{
		cudaMemcpy(dev_llast_X,			dev_X,			sizeof(TYPE)*number*3,		cudaMemcpyDeviceToDevice);
		cudaMemcpy(dev_last_X,			dev_X,			sizeof(TYPE)*number*3,		cudaMemcpyDeviceToDevice);
		cudaMemcpy(dev_tilde_X,			dev_X,			sizeof(TYPE)*number*3,		cudaMemcpyDeviceToDevice);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Reload
///////////////////////////////////////////////////////////////////////////////////////////	
	void Reload(BASIC_MESH<TYPE> &mesh)
	{
		//Update information for batch continuation.
		cudaMemcpy(dev_llast_X,			dev_last_X,		sizeof(TYPE)*number*3,		cudaMemcpyDeviceToDevice);
		cudaMemcpy(dev_last_X,			dev_X,			sizeof(TYPE)*number*3,		cudaMemcpyDeviceToDevice);
		//CUDA_Add(dev_last_X, 2.0f, dev_llast_X, -1.0f, dev_tilde_X, number*3);

		mesh.Build_XN();
		Reload_Interior(mesh);
		Initialize_Mesh_Boundary(mesh);
		cudaMemcpy(dev_X,				X,				sizeof(TYPE)*number*3,		cudaMemcpyHostToDevice);
		CUDA_Build_XN();
		cudaMemcpy(dev_init_X,			dev_X,			sizeof(TYPE)*number*3,		cudaMemcpyDeviceToDevice);
		cudaMemcpy(dev_init_XN,			dev_XN,			sizeof(TYPE)*number*3,		cudaMemcpyDeviceToDevice);
		cudaMemcpy(dev_init_XG,			dev_XG,			sizeof(TYPE)*number*3,		cudaMemcpyDeviceToDevice);

		CUDA_Spring_Length();

		Body_Projection();

		Apply_Coord();
		CUDA_Build_XN();
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Compute_Phi
///////////////////////////////////////////////////////////////////////////////////////////	
	void Compute_Phi(const float dev_X[], const float dev_XN[], const int dev_T[], const int number, const int t_number)
	{
		set->Compute(dev_X, dev_XN, dev_T, number, t_number);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Get_Smoothed_X
///////////////////////////////////////////////////////////////////////////////////////////	
	void Get_Smoothed_X()
	{
		G_Smoothing_Kernel<<<dim3(ni/BLOCK_SIZE, nj/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE)>>>
			(dev_tilde_X, dev_last_X, dev_X, dev_llast_X, dev_G, dev_M, ni, nj);

		//tilde_x=(last_+llast_X+X)/3.0f;
	//	CUDA_Add<TYPE>(dev_last_X, 6/6.0f, dev_llast_X, 0/6.0f, dev_tilde_X, number*3);
	//	CUDA_Add<TYPE>(dev_X, 0/6.0f, 0, 0, dev_tilde_X, number*3, true);

	//	CUDA_Add<TYPE>(dev_last_X, 0.0f, dev_llast_X, 1.0f, dev_tilde_X, number*3);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Fix
///////////////////////////////////////////////////////////////////////////////////////////	
	void CUDA_Fix(TYPE p0[], TYPE p1[])
	{
		SIM_TEXTURE<TYPE>::Fix(p0, p1);
		cudaMemcpy(dev_M,				M,				sizeof(char)*number,		cudaMemcpyHostToDevice);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Shirr
///////////////////////////////////////////////////////////////////////////////////////////	
	void CUDA_Shirr(TYPE p0[], TYPE p1[], TYPE R, TYPE scale, int side)
	{
		SIM_TEXTURE<TYPE>::Shirr(p0, p1, R, scale, side);
		cudaMemcpy(dev_G,				G,				sizeof(TYPE)*number*4,		cudaMemcpyHostToDevice);
		cudaMemcpy(dev_M,				M,				sizeof(char)*number,		cudaMemcpyHostToDevice);
		CUDA_Spring_Length();
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Inflate
///////////////////////////////////////////////////////////////////////////////////////////	
	void CUDA_Inflate(TYPE p0[], TYPE p1[], TYPE R, TYPE scale0, TYPE scale1)
	{
		SIM_TEXTURE<TYPE>::Inflate(p0, p1, R, scale0, scale1);
		cudaMemcpy(dev_G,				G,				sizeof(TYPE)*number*4,		cudaMemcpyHostToDevice);
		cudaMemcpy(dev_P,				P,				sizeof(TYPE)*number,		cudaMemcpyHostToDevice);
		cudaMemcpy(dev_M,				M,				sizeof(char)*number,		cudaMemcpyHostToDevice);
		CUDA_Spring_Length();
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Full_Inflate
///////////////////////////////////////////////////////////////////////////////////////////	
	void CUDA_Full_Inflate(TYPE radius, TYPE scale)
	{
		SIM_TEXTURE<TYPE>::Full_Inflate(radius, scale);
		cudaMemcpy(dev_G,				G,				sizeof(TYPE)*number*4,		cudaMemcpyHostToDevice);
		cudaMemcpy(dev_P,				P,				sizeof(TYPE)*number,		cudaMemcpyHostToDevice);
		cudaMemcpy(dev_M,				M,				sizeof(char)*number,		cudaMemcpyHostToDevice);
		CUDA_Spring_Length();
	}


///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Diamond
///////////////////////////////////////////////////////////////////////////////////////////	
	void CUDA_Diamond()
	{
		SIM_TEXTURE<TYPE>::Diamond();
		cudaMemcpy(dev_G,				G,				sizeof(TYPE)*number*4,		cudaMemcpyHostToDevice);
		cudaMemcpy(dev_P,				P,				sizeof(TYPE)*number,		cudaMemcpyHostToDevice);
		cudaMemcpy(dev_M,				M,				sizeof(char)*number,		cudaMemcpyHostToDevice);
		CUDA_Spring_Length();
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Expand
///////////////////////////////////////////////////////////////////////////////////////////	
	void CUDA_Expand(TYPE p[], TYPE radius)
	{
		SIM_TEXTURE<TYPE>::Expand(p, radius);
		cudaMemcpy(dev_G,				G,				sizeof(TYPE)*number*4,		cudaMemcpyHostToDevice);
		CUDA_Spring_Length();
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Spring_Length
///////////////////////////////////////////////////////////////////////////////////////////	
	void CUDA_Spring_Length()
	{
		//This function calculates spring length data from the deformation gradient G.
		Spring_Length_Kernel<<<dim3(ni/BLOCK_SIZE, nj/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
				(dev_X, dev_G, dev_M, dev_spring_data, h, ni, nj);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Energy
///////////////////////////////////////////////////////////////////////////////////////////	
	TYPE CUDA_Energy()
	{
		dim3 thread_block(BLOCK_SIZE, BLOCK_SIZE);
		dim3 block_grid(ni/BLOCK_SIZE, nj/BLOCK_SIZE);
		Energy_Kernel<<<block_grid, thread_block>>>(dev_energy, dev_X, dev_M, dev_spring_data, dev_bend_ID, spring_k, bending_k/(h*h), air_k, ni, nj);

		thrust::device_ptr<TYPE> dev_ptr(dev_energy);
		return thrust::reduce(dev_ptr, dev_ptr+number);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Energy
///////////////////////////////////////////////////////////////////////////////////////////	
	void Body_Projection()
	{
		dim3 thread_block(BLOCK_SIZE, BLOCK_SIZE);
		dim3 block_grid(ni/BLOCK_SIZE, nj/BLOCK_SIZE);
		Body_Projection_Kernel<<<block_grid, thread_block>>>(dev_init_X, dev_proj_X, dev_M, set->dev_texture, set->h, set->aabb.dev_aabb, ni, nj);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Update
///////////////////////////////////////////////////////////////////////////////////////////	
	void CUDA_Update(int iter=1024, int inner_loop=4)
	{
		//Body_Projection();

		TYPE alpha=0.4f;//8f;
		TYPE rho=0.992f;	//0.9992
		TYPE omega=1.0f;

		//rho=0.998f;

		cudaMemcpyAsync(dev_prev_X, dev_X, sizeof(TYPE)*number*3, cudaMemcpyDeviceToDevice, st);
		cudaMemcpyAsync(dev_next_X, dev_X, sizeof(TYPE)*number*3, cudaMemcpyDeviceToDevice, st);

		cudaMemcpy(dev_block_state0,	block_state,	sizeof(int )*number/( BLOCK_SIZE* BLOCK_SIZE),	cudaMemcpyHostToDevice);
		cudaMemcpy(dev_block_state1,	block_state,	sizeof(int )*number/( BLOCK_SIZE* BLOCK_SIZE),	cudaMemcpyHostToDevice);
		
		int skip=32;
		for(int l=0; l<iter; l++)
		{
			//printf("%f\n", CUDA_Energy());

			if(l<skip)			omega=1;
			else if(l==skip)	omega=2/(2-rho*rho);
			else				omega=4/(4-rho*rho*omega);
	
			//if(0)
			if(l<32 || l<64 && l%2==0 || l<128 && l%4==0 || l<256 && l%8==0 || l%16==0)
			{
				cudaMemsetAsync(dev_neighbor_n,	0, sizeof(int)*number, st);
				Short_Range_Search_Kernel<<<dim3(ni/BLOCK_SIZE, nj/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
					(dev_X, dev_M, dev_cblock_state, dev_neighbor, dev_neighbor_n, 0.00055f*0.00055f, ni, nj);
		
				//Obtain the pair after culling, using cblock centers.
				cudaMemsetAsync(dev_pair_n,	0, sizeof(int), st);
				Cblock_Center_Kernel<<<dim3((ni/4)/BLOCK_SIZE, (nj/4)/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
					(dev_cblock_center, dev_cblock_state, dev_X, dev_M, 4, ni/4, nj/4);				
				Long_Range_Culling_Kernel<<<dim3((ni/4)/BLOCK_SIZE, (nj/4)/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
					(dev_cblock_center, dev_cblock_state, dev_pair, dev_pair_n, max_pair_number, 50*0.000371f*0.000371f, ni/4, nj/4);
				//Perform long-range neighbor search from the pairs.
				Long_Range_Search_Kernel<<<numSMs*numThs/256, 256, 0, st>>>
					(dev_X, dev_M, dev_pair, dev_pair_n, max_pair_number, dev_neighbor, dev_neighbor_n, 0.00055f*0.00055f, ni, nj);
			}
	
			int* ptr=dev_block_state1;
			Update_Kernel<<<dim3(ni/BLOCK_SIZE, nj/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
				(dev_next_X, dev_prev_X, dev_X, dev_tilde_X, dev_init_X, dev_init_XN, dev_proj_X, use_pressure?dev_P:0, dev_M, dev_spring_data, dev_bend_data, dev_bend_ID, ptr, 
				dev_neighbor, dev_neighbor_n, spring_k, bending_k/(h*h), air_k, body_k, alpha, omega, ni, nj, inner_loop, false);


			Swap(dev_X, dev_prev_X);
			Swap(dev_X, dev_next_X);
		}

		Set_Coord_Kernel<<<dim3(ni/BLOCK_SIZE, nj/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE)>>>
			(dev_coord, dev_X, dev_init_X, dev_init_XN, dev_init_XG, dev_M, dev_G, ni, nj);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_PCG
///////////////////////////////////////////////////////////////////////////////////////////	
	void CUDA_PCG(int iter=1024, int inner_loop=5)
	{
		TYPE alpha=0.4f;//8f;
		TYPE omega=1.0f;

		cudaMemsetAsync(dev_prev_X,			0, sizeof(TYPE)*number*3, st);
		cudaMemsetAsync(dev_next_X,			0, sizeof(TYPE)*number*3, st);
		cudaMemsetAsync(dev_energy,			0, sizeof(TYPE)*number,   st);
		cudaMemsetAsync(dev_block_energy,	0, sizeof(TYPE)*number/(BLOCK_SIZE*BLOCK_SIZE),   st);

		cudaMemcpy(dev_block_state0,	block_state,	sizeof(int )*number/( BLOCK_SIZE* BLOCK_SIZE),	cudaMemcpyHostToDevice);
		cudaMemcpy(dev_block_state1,	block_state,	sizeof(int )*number/( BLOCK_SIZE* BLOCK_SIZE),	cudaMemcpyHostToDevice);
		
		TYPE last_dot=0;
		for(int l=0; l<iter; l++)
		{				
			//if(0)
			if(l<32 || l<64 && l%2==0 || l<128 && l%4==0 || l<256 && l%8==0 || l%16==0)
			{
				cudaMemsetAsync(dev_neighbor_n,	0, sizeof(int)*number, st);
				Short_Range_Search_Kernel<<<dim3(ni/BLOCK_SIZE, nj/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
					(dev_X, dev_M, dev_cblock_state, dev_neighbor, dev_neighbor_n, 0.00055f*0.00055f, ni, nj);
		
				//Obtain the pair after culling, using cblock centers.
				cudaMemsetAsync(dev_pair_n,	0, sizeof(int), st);
				Cblock_Center_Kernel<<<dim3((ni/4)/BLOCK_SIZE, (nj/4)/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
					(dev_cblock_center, dev_cblock_state, dev_X, dev_M, 4, ni/4, nj/4);				
				Long_Range_Culling_Kernel<<<dim3((ni/4)/BLOCK_SIZE, (nj/4)/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
					(dev_cblock_center, dev_cblock_state, dev_pair, dev_pair_n, max_pair_number, 50*0.000371f*0.000371f, ni/4, nj/4);
				//Perform long-range neighbor search from the pairs.
				Long_Range_Search_Kernel<<<numSMs*numThs/256, 256, 0, st>>>
					(dev_X, dev_M, dev_pair, dev_pair_n, max_pair_number, dev_neighbor, dev_neighbor_n, 0.00055f*0.00055f, ni, nj);
			}
	
	
			int* ptr=dev_block_state1;
			Update_Kernel<<<dim3(ni/BLOCK_SIZE, nj/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
				(dev_next_X, dev_prev_X, dev_X, dev_tilde_X, dev_init_X, dev_init_XN, dev_proj_X, use_pressure?dev_P:0, dev_M, dev_spring_data, dev_bend_data, dev_bend_ID, ptr, 
				dev_neighbor, dev_neighbor_n, spring_k, bending_k/(h*h), air_k, body_k, alpha, omega, ni, nj, inner_loop, false, dev_block_energy);
			  
			thrust::device_ptr<TYPE> dev_ptr(dev_block_energy);
			TYPE dot=thrust::reduce(dev_ptr, dev_ptr+number/(BLOCK_SIZE*BLOCK_SIZE));

			//thrust::device_ptr<TYPE> dev_ptr(dev_energy);
			//TYPE dot=thrust::reduce(dev_ptr, dev_ptr+number);

			TYPE beta=0;
			if(l%10!=0)		beta=dot/last_dot;


			PCG_Kernel<<<number*3/64, 64, 0, st>>>
				(dev_X, dev_prev_X, dev_next_X, dev_M, beta, 0.2f, number*3);

		//	CUDA_Add<TYPE>(dev_next_X, 1.0f, dev_prev_X, beta, dev_prev_X, number*3);
		//	CUDA_Add<TYPE>(dev_prev_X, 0.4f, 0, 0, dev_X, number*3, true);

			last_dot=dot;
		}
		
		printf("Energy: %f\n", CUDA_Energy());

		Set_Coord_Kernel<<<dim3(ni/BLOCK_SIZE, nj/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE)>>>
			(dev_coord, dev_X, dev_init_X, dev_init_XN, dev_init_XG, dev_M, dev_G, ni, nj);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Apply_Coord
///////////////////////////////////////////////////////////////////////////////////////////	
	void Apply_Coord()
	{
		Apply_Coord_Kernel<<<dim3(ni/BLOCK_SIZE, nj/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE)>>>
			(dev_coord, dev_tilde_X, dev_init_X, dev_init_XN, dev_init_XG, dev_M, dev_G, ni, nj);

		//if(0)
		for(int l=0; l<200; l++)
		{	
			{
				cudaMemsetAsync(dev_neighbor_n,	0, sizeof(int)*number, st);
				Short_Range_Search_Kernel<<<dim3(ni/BLOCK_SIZE, nj/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
					(dev_X, dev_M, dev_cblock_state, dev_neighbor, dev_neighbor_n, 0.00055f*0.00055f, ni, nj);
		
				//Obtain the pair after culling, using cblock centers.
				cudaMemsetAsync(dev_pair_n,	0, sizeof(int), st);
				Cblock_Center_Kernel<<<dim3((ni/4)/BLOCK_SIZE, (nj/4)/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
					(dev_cblock_center, dev_cblock_state, dev_X, dev_M, 4, ni/4, nj/4);				
				Long_Range_Culling_Kernel<<<dim3((ni/4)/BLOCK_SIZE, (nj/4)/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
					(dev_cblock_center, dev_cblock_state, dev_pair, dev_pair_n, max_pair_number, 50*0.000371f*0.000371f, ni/4, nj/4);
				//Perform long-range neighbor search from the pairs.
				Long_Range_Search_Kernel<<<numSMs*numThs/256, 256, 0, st>>>
					(dev_X, dev_M, dev_pair, dev_pair_n, max_pair_number, dev_neighbor, dev_neighbor_n, 0.00055f*0.00055f, ni, nj);
			}
	
			Initialize_Kernel<<<dim3(ni/BLOCK_SIZE, nj/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
				(dev_next_X, dev_X, dev_tilde_X, dev_M, dev_neighbor, dev_neighbor_n, 1, 0.01f, 1e9f, ni, nj);	//0.05f
			Swap(dev_X, dev_next_X);
		}			
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Graphed_CUDA_Update
///////////////////////////////////////////////////////////////////////////////////////////	
	/*void Graphed_CUDA_Update(int iter=1024)
	{
		if (update_cuda_graph)
		{
			//Setup cuda graph
			if(st==0)		cudaStreamCreate(&st);
			cudaDeviceSynchronize();
			if(si)			cudaGraphExecDestroy(si);
			if(graph)		cudaGraphDestroy(graph);
			cudaStreamBeginCapture(st, cudaStreamCaptureMode::cudaStreamCaptureModeGlobal);
			//Define content
			CUDA_Update(iter);
			//Terminate capture
			cudaStreamEndCapture(st, &graph);
			cudaGraphInstantiate(&si, graph, nullptr, nullptr, 0);
			//Check error
			cudaDeviceSynchronize();
			std::cout << "Cuda Graph Last Error " <<cudaGetErrorString( cudaPeekAtLastError())<< std::endl;
			update_cuda_graph = false;
		}
		//Begin execution
		cudaGraphLaunch(si, 0);		
	}*/

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Select
///////////////////////////////////////////////////////////////////////////////////////////	
	int CUDA_Select(TYPE p[], TYPE q[])
	{
		TYPE dir[3];
		dir[0]=q[0]-p[0];
		dir[1]=q[1]-p[1];
		dir[2]=q[2]-p[2];
		Normalize(dir);

		cudaMemset(dev_selection, 0, sizeof(int));
		Select_Kernel<<<dim3(ni/BLOCK_SIZE, nj/BLOCK_SIZE), dim3(BLOCK_SIZE, BLOCK_SIZE), 0, st>>>
				(dev_X, dev_M, dev_selection, selection_length, p[0], p[1], p[2], dir[0], dir[1], dir[2], ni, nj, h);

		//printf("selection_length: %d: %d\n", selection_length, selection[0]);
		cudaMemcpy(selection, dev_selection, sizeof(int)*selection_length, cudaMemcpyDeviceToHost);

		int  min_i=-1;
		TYPE min_t=(TYPE)MY_INFINITE;
		TYPE min_d=(TYPE)MY_INFINITE;
		for(int addr=1; addr<=selection[0]; addr++)
		{
			if(addr>=selection_length)		break;
			int i=selection[addr];

			TYPE v[3];
			v[0]=X[i*3+0]-p[0];
			v[1]=X[i*3+1]-p[1];
			v[2]=X[i*3+2]-p[2];

			TYPE t=DOT(v, dir);
			TYPE d=	(v[0]-t*dir[0])*(v[0]-t*dir[0])+
					(v[1]-t*dir[1])*(v[1]-t*dir[1])+
					(v[2]-t*dir[2])*(v[2]-t*dir[2]);
			if(t<min_t-0.005f || t<min_t+0.005f && d<min_d)
			{
				min_i=i;
				min_t=t;
				min_d=d;
			}
		}
		return min_i;
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Build_XN
///////////////////////////////////////////////////////////////////////////////////////////	
	void CUDA_Build_XN()
	{
		cudaMemset(dev_XN, 0, sizeof(TYPE)*number*3);
		cudaMemset(dev_XG, 0, sizeof(TYPE)*number*3);		
		
		int threadsPerBlock	= 128;
		int t_blocksPerGrid	= (t_number + threadsPerBlock - 1)	/ threadsPerBlock;
		Add_XN_XG_Kernel2<<<t_blocksPerGrid, threadsPerBlock>>>	(dev_X, dev_R, dev_XN, dev_XG, dev_T, t_number);

		CUDA_Normalize(dev_XN, number);
		CUDA_Normalize(dev_XG, number);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Set_Color
///////////////////////////////////////////////////////////////////////////////////////////	
	void CUDA_Set_Color(TYPE r, TYPE g, TYPE b)
	{
		for(int id=0; id<number; id++)
		{
			C[id*3+0]=r;
			C[id*3+1]=g;
			C[id*3+2]=b;
		}
		cudaMemcpy(dev_C, C, sizeof(TYPE)*number*3, cudaMemcpyHostToDevice);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  CUDA_Set_Color_from_G
///////////////////////////////////////////////////////////////////////////////////////////	
	void CUDA_Set_Color_from_G()
	{
		for(int id=0; id<number; id++)
		//	Spectrum<TYPE>(G[id*4+0], &C[id*3], 1.0, 2.0);
			Spectrum<TYPE>((G[id*4+0]*G[id*4+3]-G[id*4+1]*G[id*4+1])/(G[id*4+2]*G[id*4+2]), &C[id*3], 1, 1.5);
		cudaMemcpy(dev_C, C, sizeof(TYPE)*number*3, cudaMemcpyHostToDevice);
	}
};



