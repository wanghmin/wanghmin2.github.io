I didn't spend too much time on cleaning up the code.  

I apologize if some parts are not so readable to you.  

The whole program is similar to the projective dynamics program I released one year ago.  

If you are familar with that, you should be able to follow this code easily as well.

This code includes only one example: Armadillo.  

If you are interested in other examples, please email me.  

Feel free to ask if you have any question too.


I plan to release a simplified and faster version for quasistatic simulation only.

Huamin Wang
9/25/2016