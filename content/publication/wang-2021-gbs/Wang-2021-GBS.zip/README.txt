SIM_TEXTURE.h:		CPU version
CUDA_SIM_TEXTURE.h:	GPU version

These two files are used for your reference.
The other files needed for running the whole project are omitted here and can be accessible upon request.
