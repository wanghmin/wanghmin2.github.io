///////////////////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 2002 - 2020, Huamin Wang
//  All rights reserved.
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//     1. Redistributions of source code must retain the above copyright
//        notice, this list of conditions and the following disclaimer.
//     2. Redistributions in binary form must reproduce the above copyright
//        notice, this list of conditions and the following disclaimer in the
//        documentation and/or other materials provided with the distribution.
//     3. The names of its contributors may not be used to endorse or promote
//        products derived from this software without specific prior written
//        permission.
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
//  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
//  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
//  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
//  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//	NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//	SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
///////////////////////////////////////////////////////////////////////////////////////////
//  Class SIM_TEXTURE
///////////////////////////////////////////////////////////////////////////////////////////
#pragma once
#include "../lib/PROGRESSING_BAR.h"
#include "../lib/BASIC_MESH.h"
#include "../lib/DISTANCE.h"
#include "../lib/TIMER.h"
#include "../lib/BMP_IO.h"

#define CBLOCK_SIZE		4
#define BLOCK_SIZE		8
#define BLOCK_BUFF		2
#define INDEX(i, j)	((i)*(nj)+j)

#define EMPTY_MASK		 0
#define BOUNDARY_MASK	-1
#define FIXED_MASK		-2
#define VALID_MASK		 1
#define BODY_VALID_MASK	 2

template <class TYPE>
class SIM_TEXTURE
{
public:
	int		number;
	int		t_number;
	int		ni;
	int		nj;
	TYPE	h;

	TYPE*	X			= 0;	//Position
	TYPE*	R			= 0;	//Reference
	TYPE*	XN			= 0;
	TYPE*	XG			= 0;
	TYPE*	C			= 0;	//Color
	int*	T			= 0;	//Triangle
	TYPE*	G			= 0;	//Deformation gradient
	TYPE*	P			= 0;	//Pressure
	char*	M			= 0;	//Mask
	TYPE*	prev_X		= 0;
	TYPE*	curr_X		= 0;
	TYPE*	next_X		= 0;
	TYPE*	Noise_4		= 0;
	TYPE*	Noise_8		= 0;

	TYPE*	spring_data	= 0;
	int*	bend_ID		= 0;
	TYPE	compact_bend_data[256][12];
	TYPE*	bend_data	= 0;
	int*	block_state	= 0;
	int*	cblock_state= 0;

	TYPE*	min_d		= 0;
	TYPE*	min_p		= 0;


	int*	selection			= 0;
	int		selection_length	= 256;
	TYPE	spring_k		= 100000;	//100000
	TYPE	bending_k		= 2.0f;	//1.10f
	TYPE 	air_k			= 0;//1e6f;
	TYPE	body_k			= 1000000;
	TYPE	boundary_angle	= - MY_PI*0.5f;

	bool	use_pressure	= true;
///////////////////////////////////////////////////////////////////////////////////////////
//  Constructor and Deconstructor
///////////////////////////////////////////////////////////////////////////////////////////
	SIM_TEXTURE()
	{}

	~SIM_TEXTURE()
	{
		if(X)				delete[] X;
		if(R)				delete[] R;
		if(XN)				delete[] XN;
		if(XG)				delete[] XG;
		if(C)				delete[] C;
		if(T)				delete[] T;
		if(G)				delete[] G;
		if(P)				delete[] P;
		if(M)				delete[] M;

		if(prev_X)			delete[] prev_X;
		if(curr_X)			delete[] curr_X;
		if(next_X)			delete[] next_X;

		if(Noise_4)			delete[] Noise_4;
		if(Noise_8)			delete[] Noise_8;

		if(spring_data)		delete[] spring_data;
		if(bend_ID)			delete[] bend_ID;
		if(bend_data)		delete[] bend_data;
		if(block_state)		delete[] block_state;
		if(cblock_state)	delete[] cblock_state;

		if(min_d)			delete[] min_d;
		if(min_p)			delete[] min_p;

		if(selection)		delete[] selection;
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Allocate_Memory
///////////////////////////////////////////////////////////////////////////////////////////
	void Allocate_Memory(int _ni, int _nj)
	{
		ni		= _ni;
		nj		= _nj;
		number	= ni*nj;
		t_number= (ni-1)*(nj-1)*2;
	
		X			= new TYPE[number*3  ];
		R			= new TYPE[number*3  ];
		XN			= new TYPE[number*3  ];
		XG			= new TYPE[number*3  ];
		C			= new TYPE[number*3  ];
		T			= new int [t_number*3];
		G			= new TYPE[number*4  ];
		M			= new char[number    ];
		P			= new TYPE[number    ]{};
		prev_X		= new TYPE[number*3  ]{};
		curr_X		= new TYPE[number*3  ]{};
		next_X		= new TYPE[number*3  ]{};
		Noise_4		= new TYPE[number    ]{};
		Noise_8		= new TYPE[number    ]{};

		spring_data	= new TYPE[number*6  ]{};
		bend_ID		= new int [number    ]{};
		bend_data	= new TYPE[number*12 ]{};
		block_state	= new int [number/( BLOCK_SIZE* BLOCK_SIZE)]{};
		cblock_state= new int [number/(CBLOCK_SIZE*CBLOCK_SIZE)]{};

		min_d		= new TYPE[number  ]{};
		min_p		= new TYPE[number*3]{};

		selection	= new int [selection_length]{};

		//Create Noise.
		int gap;
		
		gap=4;
		for(int i=0; i<ni; i+=gap)
		for(int j=0; j<nj; j+=gap)
			Noise_4[INDEX(i, j)]=RandomFloat();
		for(int i=0; i<ni; i+=1)
		for(int j=0; j<nj; j+=1)
		{
			int i0=(i/gap)*gap;
			int j0=(j/gap)*gap;
			if(i0+gap>=ni)	continue;
			if(j0+gap>=nj)	continue;
			TYPE a=(TYPE)(i-i0)/gap;
			TYPE b=(TYPE)(j-j0)/gap;

			Noise_4[INDEX(i, j)]=
				(1-a)*(1-b)*Noise_4[INDEX(i0,     j0    )]+
				(1-a)*(  b)*Noise_4[INDEX(i0,     j0+gap)]+
				(  a)*(1-b)*Noise_4[INDEX(i0+gap, j0    )]+
				(  a)*(  b)*Noise_4[INDEX(i0+gap, j0+gap)];
		}

		gap=8;
		for(int i=0; i<ni; i+=gap)
		for(int j=0; j<nj; j+=gap)
			Noise_8[INDEX(i, j)]=RandomFloat();
		for(int i=0; i<ni; i+=1)
		for(int j=0; j<nj; j+=1)
		{
			int i0=(i/gap)*gap;
			int j0=(j/gap)*gap;
			if(i0+gap>=ni)	continue;
			if(j0+gap>=nj)	continue;
			TYPE a=(TYPE)(i-i0)/gap;
			TYPE b=(TYPE)(j-j0)/gap;

			Noise_8[INDEX(i, j)]=
				(1-a)*(1-b)*Noise_8[INDEX(i0,     j0    )]+
				(1-a)*(  b)*Noise_8[INDEX(i0,     j0+gap)]+
				(  a)*(1-b)*Noise_8[INDEX(i0+gap, j0    )]+
				(  a)*(  b)*Noise_8[INDEX(i0+gap, j0+gap)];
		}
		//BMP_Write("test.bmp", Noise, ni, nj, 1, 0.0f, 255.0f);

	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Initialize_Arrays
///////////////////////////////////////////////////////////////////////////////////////////
	void Initialize_Arrays()
	{
		//Initialize triangles.
		t_number=0;
		for(int i=0; i<ni-1; i++)	
		for(int j=0; j<nj-1; j++)
		{
			T[t_number*3+0]=INDEX(i, j);
			T[t_number*3+1]=INDEX(i, j+1);
			T[t_number*3+2]=INDEX(i+1, j);
			t_number++;
			T[t_number*3+0]=INDEX(i, j+1);
			T[t_number*3+1]=INDEX(i+1, j+1);
			T[t_number*3+2]=INDEX(i+1, j);
			t_number++;
		}

		//Initialize mask and strain field.
		for(int id=0; id<number; id++)
		{
			M[id	]=VALID_MASK;
			G[id*4+0]=1;
			G[id*4+2]=1;	//Stores the weight.
			G[id*4+3]=1;
		}

		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		{
			int id=INDEX(i, j);
			R[id*3+0]=j*h;
			R[id*3+1]=i*h;
			R[id*3+2]=0;
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Range_Padding
///////////////////////////////////////////////////////////////////////////////////////////
	void Range_Padding(int s, int value=EMPTY_MASK)
	{
		for(int i=0; i<ni; i++)
		for(int j=0; j<s; j++)
		{
			M[INDEX(i, j)]	   =value;
			M[INDEX(i, nj-j-1)]=value;
		}
		for(int i=0; i<s; i++)
		for(int j=0; j<nj; j++)
		{
			M[INDEX(i, j)]	   =value;
			M[INDEX(ni-i-1, j)]=value;
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Boundary_Padding
///////////////////////////////////////////////////////////////////////////////////////////
	void Boundary_Padding(int s, int value=BOUNDARY_MASK)
	{
		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		if(M[INDEX(i, j)]>0 && (M[INDEX(i-1, j)]<=0 || M[INDEX(i+1, j)]<=0 || M[INDEX(i, j-1)]<=0 || M[INDEX(i-1, j+1)]<=0))
		{
			for(int ii=-s; ii<=s; ii++)
			for(int jj=-s; jj<=s; jj++)
				if(M[INDEX(i+ii, j+jj)]==EMPTY_MASK)	
					M[INDEX(i+ii, j+jj)]=value;
		}
	}
	
///////////////////////////////////////////////////////////////////////////////////////////
//  Set_Mask_from_Mesh
///////////////////////////////////////////////////////////////////////////////////////////
	void Set_Mask_from_Mesh(BASIC_MESH<TYPE> &mesh)
	{
		//Set the mask
		for(int i=0; i<number; i++)		M[i]=EMPTY_MASK;

		for(int t=0; t<mesh.t_number; t++)
		{
			TYPE* p0=&mesh.R[mesh.T[t*3+0]*3];
			TYPE* p1=&mesh.R[mesh.T[t*3+1]*3];
			TYPE* p2=&mesh.R[mesh.T[t*3+2]*3];

			int lower_i=ceil(Min(p0[1], p1[1], p2[1]));
			int upper_i=ceil(Max(p0[1], p1[1], p2[1]));
			int lower_j=ceil(Min(p0[0], p1[0], p2[0]));
			int upper_j=ceil(Max(p0[0], p1[0], p2[0]));

			for(int i=lower_i; i<upper_i; i++)
			for(int j=lower_j; j<upper_j; j++)
			{
				if(i<0 || i>=ni)	continue;
				if(j<0 || j>=nj)	continue;
				TYPE p[3]={(TYPE)j, (TYPE)i, 0};

				TYPE b2=(p1[0]-p0[0])*(p[1]-p0[1])-(p1[1]-p0[1])*(p[0]-p0[0]);
				TYPE b0=(p2[0]-p1[0])*(p[1]-p1[1])-(p2[1]-p1[1])*(p[0]-p1[0]);
				TYPE b1=(p0[0]-p2[0])*(p[1]-p2[1])-(p0[1]-p2[1])*(p[0]-p2[0]);

				TYPE sum_b=b0+b1+b2;
				if(sum_b>0 && (b0<0 || b1<0 || b2<0))	continue;
				if(sum_b<0 && (b0>0 || b1>0 || b2>0))	continue;

				M[INDEX(i, j)]=VALID_MASK;
				X[INDEX(i, j)*3+0]=(b0*mesh.X[mesh.T[t*3+0]*3+0]+b1*mesh.X[mesh.T[t*3+1]*3+0]+b2*mesh.X[mesh.T[t*3+2]*3+0])/sum_b;
				X[INDEX(i, j)*3+1]=(b0*mesh.X[mesh.T[t*3+0]*3+1]+b1*mesh.X[mesh.T[t*3+1]*3+1]+b2*mesh.X[mesh.T[t*3+2]*3+1])/sum_b;
				X[INDEX(i, j)*3+2]=(b0*mesh.X[mesh.T[t*3+0]*3+2]+b1*mesh.X[mesh.T[t*3+1]*3+2]+b2*mesh.X[mesh.T[t*3+2]*3+2])/sum_b;				
			}
		}

		Range_Padding(16);
		Boundary_Padding(4);

	//	for(int i=0; i<ni; i++)
	//	for(int j=0; j<nj; j++)
	//		if(M[INDEX(i, j)])	M[INDEX(i, j)]=VALID_MASK;

		//Set the block state.
		memset(block_state, 0, sizeof(int)*number/(BLOCK_SIZE*BLOCK_SIZE));
		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		if(M[INDEX(i, j)]==VALID_MASK)		
			block_state[(i/BLOCK_SIZE)*(nj/BLOCK_SIZE)+j/BLOCK_SIZE]++;	

		//Set the cblock state.
		memset(cblock_state, 0, sizeof(int)*number/(CBLOCK_SIZE*CBLOCK_SIZE));
		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		if(M[INDEX(i, j)]!=EMPTY_MASK)
			cblock_state[(i/CBLOCK_SIZE)*(nj/CBLOCK_SIZE)+j/CBLOCK_SIZE]=1;	

		//Reduce_Triangles
		Reduce_Triangles();
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Reduce_Triangles
///////////////////////////////////////////////////////////////////////////////////////////
	void Reduce_Triangles()
	{
		int new_t_number=0;
		for(int t=0; t<t_number; t++)
		{
			if(M[T[t*3+0]]==EMPTY_MASK || M[T[t*3+1]]==EMPTY_MASK || M[T[t*3+2]]==EMPTY_MASK)	continue;

			T[new_t_number*3+0]=T[t*3+0];
			T[new_t_number*3+1]=T[t*3+1];
			T[new_t_number*3+2]=T[t*3+2];
			new_t_number++;
		}
		t_number=new_t_number;
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Initialize
///////////////////////////////////////////////////////////////////////////////////////////
	void Initialize(TYPE _h, BASIC_MESH<TYPE> &mesh)
	{
		h = _h;

		TIMER timer;

		Initialize_Arrays();

		Set_Mask_from_Mesh(mesh);
		printf("A: %f\n", timer.Get_Time());

		Initialize_Mesh_Boundary(mesh);
		printf("B: %f\n", timer.Get_Time());

		Spring_Length();
		printf("C: %f\n", timer.Get_Time());

		//Bending_Data();
		printf("D: %f\n", timer.Get_Time());
	}


///////////////////////////////////////////////////////////////////////////////////////////
//  Spring_Length
///////////////////////////////////////////////////////////////////////////////////////////
	TYPE Spring_Length(int i0, int j0, int i1, int j1, TYPE G[], TYPE M[], int ni, int nj, TYPE h)
	{
		if(Is_Valid(i0, j0)==false)		return 0;
		if(Is_Valid(i1, j1)==false)		return 0;
		int id0=INDEX(i0, j0);
		int id1=INDEX(i1, j1);

		TYPE w=G[id0*4+2]+G[id1*4+2];
		if(w==0)						return 0;
		TYPE s[4];
		s[0]=(G[id0*4+0]+G[id1*4+0])/w;
		s[1]=(G[id0*4+1]+G[id1*4+1])/w;
		s[2]=s[1];
		s[3]=(G[id0*4+3]+G[id1*4+3])/w;
		return sqrtf(SQR(s[0]*(i1-i0)+s[1]*(j1-j0))+SQR(s[2]*(i1-i0)+s[3]*(j1-j0)))*h;
	}

	void Spring_Length()
	{
		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		if(Is_Valid(i, j))
		{
			int id=INDEX(i, j);
			spring_data[0*number+id]=Spring_Length(i, j, i-1, j,	G, M, ni, nj, h);
			spring_data[1*number+id]=Spring_Length(i, j, i,   j-1,	G, M, ni, nj, h);
			spring_data[2*number+id]=Spring_Length(i, j, i+1, j-1,	G, M, ni, nj, h);
			spring_data[3*number+id]=Spring_Length(i, j, i+1, j,	G, M, ni, nj, h);
			spring_data[4*number+id]=Spring_Length(i, j, i,   j+1,	G, M, ni, nj, h);
			spring_data[5*number+id]=Spring_Length(i, j, i-1, j+1,	G, M, ni, nj, h);
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Bending_Data
///////////////////////////////////////////////////////////////////////////////////////////
	void Bending_Data()
	{
		/*int compact_bend_number;
		compact_bend_number=Compact_Bending_Data(bend_ID, compact_bend_data);
		
		printf("test: %f, %f, %f; %f, %f, %f; %f, %f, %f; %f, %f, %f\n",
			compact_bend_data[0][ 0]*h*h,
			compact_bend_data[0][ 1]*h*h,
			compact_bend_data[0][ 2]*h*h,
			compact_bend_data[0][ 3]*h*h,
			compact_bend_data[0][ 4]*h*h,
			compact_bend_data[0][ 5]*h*h,
			compact_bend_data[0][ 6]*h*h,
			compact_bend_data[0][ 7]*h*h,
			compact_bend_data[0][ 8]*h*h,
			compact_bend_data[0][ 9]*h*h,
			compact_bend_data[0][10]*h*h,
			compact_bend_data[0][11]*h*h);

		Get_Raw_Bending_Data3(bend_data);

		printf("9996330: %f, %f, %f; %f, %f, %f; %f, %f, %f, %f, %f, %f\n",
			bend_data[ 0*number+9996330]*h*h,
			bend_data[ 1*number+9996330]*h*h,
			bend_data[ 2*number+9996330]*h*h,
			bend_data[ 3*number+9996330]*h*h,
			bend_data[ 4*number+9996330]*h*h,
			bend_data[ 5*number+9996330]*h*h,
			bend_data[ 6*number+9996330]*h*h,
			bend_data[ 7*number+9996330]*h*h,
			bend_data[ 8*number+9996330]*h*h,
			bend_data[ 9*number+9996330]*h*h,
			bend_data[10*number+9996330]*h*h,
			bend_data[11*number+9996330]*h*h);

		printf("9996331: %f, %f, %f; %f, %f, %f; %f, %f, %f, %f, %f, %f\n",
			bend_data[ 0*number+9996331]*h*h,
			bend_data[ 1*number+9996331]*h*h,
			bend_data[ 2*number+9996331]*h*h,
			bend_data[ 3*number+9996331]*h*h,
			bend_data[ 4*number+9996331]*h*h,
			bend_data[ 5*number+9996331]*h*h,
			bend_data[ 6*number+9996331]*h*h,
			bend_data[ 7*number+9996331]*h*h,
			bend_data[ 8*number+9996331]*h*h,
			bend_data[ 9*number+9996331]*h*h,
			bend_data[10*number+9996331]*h*h,
			bend_data[11*number+9996331]*h*h);*/

	/*	printf("v: %f, %f, %f; %f, %f, %f; %f, %f, %f, %f, %f, %f\n",
			compact_bend_data[bend_ID[10188599]][0]*h*h,
			compact_bend_data[bend_ID[10188599]][1]*h*h,
			compact_bend_data[bend_ID[10188599]][2]*h*h,
			compact_bend_data[bend_ID[10188599]][3]*h*h,
			compact_bend_data[bend_ID[10188599]][4]*h*h,
			compact_bend_data[bend_ID[10188599]][5]*h*h,
			compact_bend_data[bend_ID[10188599]][6]*h*h,
			compact_bend_data[bend_ID[10188599]][7]*h*h,
			compact_bend_data[bend_ID[10188599]][8]*h*h,
			compact_bend_data[bend_ID[10188599]][9]*h*h,
			compact_bend_data[bend_ID[10188599]][10]*h*h,
			compact_bend_data[bend_ID[10188599]][11]*h*h);

		TYPE* bend_data	=new TYPE[number*16];
		TYPE* bend_data2=new TYPE[number*16];
		Get_Raw_Bending_Data(bend_data);
		Get_Raw_Bending_Data2(bend_data2);

		TYPE* data =bend_data;
		TYPE* data2=bend_data2;

		for(int i=0; i<number; i++)
		{
			if(	fabsf(data2[ 0*number+i]-data[ 0*number+i])>100 ||
				fabsf(data2[ 1*number+i]-data[ 1*number+i])>100 ||
				fabsf(data2[ 2*number+i]-data[ 2*number+i])>100 ||
				fabsf(data2[ 3*number+i]-data[ 3*number+i])>100 ||
				fabsf(data2[ 4*number+i]-data[ 4*number+i])>100 ||
				fabsf(data2[ 5*number+i]-data[ 5*number+i])>100 ||
				fabsf(data2[ 6*number+i]-data[ 6*number+i])>100 ||
				fabsf(data2[ 7*number+i]-data[ 7*number+i])>100 ||
				fabsf(data2[ 8*number+i]-data[ 8*number+i])>100 ||
				fabsf(data2[ 9*number+i]-data[ 9*number+i])>100 ||
				fabsf(data2[10*number+i]-data[10*number+i])>100 ||
				fabsf(data2[11*number+i]-data[11*number+i])>100 )
			{
				printf("a %d: %f, %f, %f; %f, %f, %f; %f, %f, %f; %f, %f, %f\n", i,
					data2[ 0*number+i], data2[ 1*number+i], data2[ 2*number+i],
					data2[ 3*number+i], data2[ 4*number+i], data2[ 5*number+i],
					data2[ 6*number+i], data2[ 7*number+i], data2[ 8*number+i],
					data2[ 9*number+i], data2[10*number+i], data2[11*number+i]);

				printf("b %d: %f, %f, %f; %f, %f, %f; %f, %f, %f; %f, %f, %f\n", i,
					data[ 0*number+i], data[ 1*number+i], data[ 2*number+i],
					data[ 3*number+i], data[ 4*number+i], data[ 5*number+i],
					data[ 6*number+i], data[ 7*number+i], data[ 8*number+i],
					data[ 9*number+i], data[10*number+i], data[11*number+i]);

				getchar();
			}
		}

		//compact_bend_number=Compress_Bending_Data(bend_ID, compact_bend_data, bend_data);
		//Verify_Compact_Bending_Data(bend_ID, compact_bend_data, bend_data);

		delete[] bend_data2;
		delete[] bend_data;*/
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Initialize_Mesh_Boundary
///////////////////////////////////////////////////////////////////////////////////////////
	void Initialize_Mesh_Boundary(BASIC_MESH<TYPE> &mesh)
	{
		for(int id=0; id<number; id++)
			min_d[id]=MY_INFINITE;
		

		/*for(int id=0; id<number; id++)
		{
			P[id]=0.5f;

			G[id*4+0]=1.05f;
			G[id*4+1]=0;
			G[id*4+2]=1;
			G[id*4+3]=1.05f;
		}*/

		for(int e=0; e<mesh.e_number; e++)
		if(mesh.ET[e*2]==-1 || mesh.ET[e*2+1]==-1)
		{
			int i=mesh.E[e*2+0];
			int j=mesh.E[e*2+1];
			Initialize_Boundary_Edge(&mesh.X[i*3], &mesh.X[j*3], &mesh.XN[i*3], &mesh.XN[j*3], &mesh.R[i*3], &mesh.R[j*3], 0.01f/h, h, 1.2f, 2, boundary_angle);
		//	Initialize_Boundary_Edge(&mesh.X[i*3], &mesh.X[j*3], &mesh.XN[i*3], &mesh.XN[j*3], &mesh.R[i*3], &mesh.R[j*3], 0.01f/h, h, 1.2f, 2, -MY_PI*0.5f);
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Reload_Interior
///////////////////////////////////////////////////////////////////////////////////////////
	void Reload_Interior(BASIC_MESH<TYPE> &mesh)
	{
		for(int t=0; t<mesh.t_number; t++)
		{
			TYPE* p0=&mesh.R[mesh.T[t*3+0]*3];
			TYPE* p1=&mesh.R[mesh.T[t*3+1]*3];
			TYPE* p2=&mesh.R[mesh.T[t*3+2]*3];

			int lower_i=ceil(Min(p0[1], p1[1], p2[1]));
			int upper_i=ceil(Max(p0[1], p1[1], p2[1]));
			int lower_j=ceil(Min(p0[0], p1[0], p2[0]));
			int upper_j=ceil(Max(p0[0], p1[0], p2[0]));

			for(int i=lower_i; i<upper_i; i++)
			for(int j=lower_j; j<upper_j; j++)
			{
				if(i<0 || i>=ni)	continue;
				if(j<0 || j>=nj)	continue;
				TYPE p[3]={(TYPE)j, (TYPE)i, 0};

				TYPE b2=(p1[0]-p0[0])*(p[1]-p0[1])-(p1[1]-p0[1])*(p[0]-p0[0]);
				TYPE b0=(p2[0]-p1[0])*(p[1]-p1[1])-(p2[1]-p1[1])*(p[0]-p1[0]);
				TYPE b1=(p0[0]-p2[0])*(p[1]-p2[1])-(p0[1]-p2[1])*(p[0]-p2[0]);

				TYPE sum_b=b0+b1+b2;
				if(sum_b>0 && (b0<0 || b1<0 || b2<0))	continue;
				if(sum_b<0 && (b0>0 || b1>0 || b2>0))	continue;

				X[INDEX(i, j)*3+0]=(b0*mesh.X[mesh.T[t*3+0]*3+0]+b1*mesh.X[mesh.T[t*3+1]*3+0]+b2*mesh.X[mesh.T[t*3+2]*3+0])/sum_b;
				X[INDEX(i, j)*3+1]=(b0*mesh.X[mesh.T[t*3+0]*3+1]+b1*mesh.X[mesh.T[t*3+1]*3+1]+b2*mesh.X[mesh.T[t*3+2]*3+1])/sum_b;
				X[INDEX(i, j)*3+2]=(b0*mesh.X[mesh.T[t*3+0]*3+2]+b1*mesh.X[mesh.T[t*3+1]*3+2]+b2*mesh.X[mesh.T[t*3+2]*3+2])/sum_b;


				//printf("%f, %f, %f\n", X[INDEX(i, j)*3+0], X[INDEX(i, j)*3+1], X[INDEX(i, j)*3+2]);
			}
		}

	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Initialize_Boundary
//	This is a rather ad hoc function that includes two operations: boundary shirring
//	and boundary folding.  This needs more clean-up work.
///////////////////////////////////////////////////////////////////////////////////////////
	void Initialize_Boundary_Edge(TYPE x0[], TYPE x1[], TYPE n0[], TYPE n1[], TYPE p0[], TYPE p1[], TYPE R, TYPE h, TYPE scale, int side, TYPE theta)
	{
		TYPE u[3];
		u[0]=p1[0]-p0[0];
		u[1]=p1[1]-p0[1];
		u[2]=p1[2]-p0[2];
		TYPE u_length=Normalize(u);
		TYPE g[4];
		g[0]= scale*u[1]*u[1]+u[0]*u[0];
		g[1]=(scale-1)*u[0]*u[1];
		g[2]=(scale-1)*u[0]*u[1];
		g[3]= scale*u[0]*u[0]+u[1]*u[1];

		int lower[2];
		int upper[2];
		lower[0]=MAX((MIN(p0[0], p1[0])-R*2)-1, 0);
		lower[1]=MAX((MIN(p0[1], p1[1])-R*2)-1, 0);
		upper[0]=MIN((MAX(p0[0], p1[0])+R*2)+1, nj-1);
		upper[1]=MIN((MAX(p0[1], p1[1])+R*2)+1, ni-1);

		TYPE R2=R*R;
		for(int i=lower[1]; i<=upper[1]; i++)
		for(int j=lower[0]; j<=upper[0]; j++)
		{
			int id=INDEX(i, j);
			if(M[id]==EMPTY_MASK)	continue;

			TYPE pp0[2];
			pp0[0]=j-p0[0];
			pp0[1]=i-p0[1];

			TYPE b=u[0]*pp0[0]+u[1]*pp0[1];
			b=CLAMP(b, 0, u_length);
			TYPE d2=SQR(pp0[0]-b*u[0])+SQR(pp0[1]-b*u[1]);

			if(M[id]==BOUNDARY_MASK && d2<min_d[id])
			{
				min_d[id]=d2;
				min_p[id*3+1]=p0[0]+b*u[0];
				min_p[id*3+0]=p0[1]+b*u[1];
				min_p[id*3+2]=0;

				TYPE ppc[2];
				ppc[0]=pp0[0]-b*u[0];
				ppc[1]=pp0[1]-b*u[1];

				TYPE u_value=(u[0]*ppc[0]+u[1]*ppc[1]);
				TYPE v_value=(u[0]*ppc[1]-u[1]*ppc[0]);

				TYPE U[3];
				U[0]=x1[0]-x0[0];
				U[1]=x1[1]-x0[1];
				U[2]=x1[2]-x0[2];
				Normalize(U);
				TYPE N[3];
				N[0]=n0[0]+(b/u_length)*(n1[0]-n0[0]);
				N[1]=n0[1]+(b/u_length)*(n1[1]-n0[1]);
				N[2]=n0[2]+(b/u_length)*(n1[2]-n0[2]);
				Normalize(N);

				TYPE V[3];
				CROSS(N, U, V);
				Normalize(V);

				TYPE d=sqrt(d2);
				X[id*3+0]=x0[0]+(b/u_length)*(x1[0]-x0[0])+(u_value*U[0]+v_value*V[0])*cos(theta)*h+N[0]*sin(theta)*d*h;
				X[id*3+1]=x0[1]+(b/u_length)*(x1[1]-x0[1])+(u_value*U[1]+v_value*V[1])*cos(theta)*h+N[1]*sin(theta)*d*h;
				X[id*3+2]=x0[2]+(b/u_length)*(x1[2]-x0[2])+(u_value*U[2]+v_value*V[2])*cos(theta)*h+N[2]*sin(theta)*d*h;


			//	X[id*3+0]=min_pt[id*3+0]+cos(theta)*(j-min_pt[id*3+0]);
			//	X[id*3+1]=min_pt[id*3+1]+cos(theta)*(i-min_pt[id*3+1]);
			//	X[id*3+2]=-sin(theta)*d;

				//if(b>0 && b<u_length)
			//	printf("u_value: %f: %f\n", u_value, b);

			//	printf("??? %f, %f\n", u_value, v_value);

				//min_pt[id*3+0]=(1-r)*p0[0]+r*p1[0];
				//min_pt[id*3+1]=(1-r)*p0[1]+r*p1[1];
				//min_pt[id*3+2]=(1-r)*p0[2]+r*p1[2];
			}

			if(d2<R2)
			{
				//if(i<lower[1] || i>upper[1] || j<lower[0] || j>upper[0])
				//printf("%d, %d (%d, %d: %d, %d)\n", i, j, lower[0], lower[1], upper[0], upper[1]);
/*
				TYPE cross=u[0]*pp0[1]-u[1]*pp0[0];
				if(side==0 && cross>0)	continue;
				if(side==1 && cross<0)	continue;

				float w=1-sqrtf(d2/R2);
				w=w*w;
				w=w*w;
				w=w*w;
				w=w*w;
				G[id*4+0]+=g[0]*w;
				G[id*4+1]+=g[1]*w;
				G[id*4+2]+=w;
				G[id*4+3]+=g[3]*w;*/
			}
		}
	}

	/*void Boundary_Fold(int i, int j)
	{
		int id =INDEX(i, j);
		TYPE* p=&min_p[id*3];
		int pi=p[0];
	}

	void Boundary_Fold(int i, int j, int pi, int pj, TYPE pa, TYPE pb, TYPE x[])
	{
		int pid=INDEX(pi, pj);

		int pid0, pid1;
		TYPE U[3], V[3];

		if(M[INDEX(pi-1, pj)]==1)	pid0=INDEX(pi-1, pj);
		else						pid0=pid;
		if(M[INDEX(pi+1, pj)]==1)	pid1=INDEX(pi+1, pj);
		else						pid1=pid;
		if(pid0==pid1)		return;
		U[0]=X[pid1*3+0]-X[pid0*3+0];
		U[1]=X[pid1*3+1]-X[pid0*3+1];
		U[2]=X[pid1*3+2]-X[pid0*3+2];
		if(pid0!=pid && pid1!=pid)
		{
			U[0]*=0.5f;
			U[1]*=0.5f;
			U[2]*=0.5f;
		}

		if(M[INDEX(pi, pj-1)]==1)	pid0=INDEX(pi, pj-1);
		else						pid0=pid;
		if(M[INDEX(pi, pj+1)]==1)	pid1=INDEX(pi, pj+1);
		else						pid1=pid;
		if(pid0==pid1)		return;
		V[0]=X[pid1*3+0]-X[pid0*3+0];
		V[1]=X[pid1*3+1]-X[pid0*3+1];
		V[2]=X[pid1*3+2]-X[pid0*3+2];
		if(pid0!=pid && pid1!=pid)
		{
			V[0]*=0.5f;
			V[1]*=0.5f;
			V[2]*=0.5f;
		}		
		
		x[0]=X[pid*3+0]+(i-pi)*U[0]+(j-pj)*V[0];
		x[1]=X[pid*3+1]+(i-pi)*U[1]+(j-pj)*V[1];
		x[2]=X[pid*3+2]+(i-pi)*U[2]+(j-pj)*V[2];				
	}*/

///////////////////////////////////////////////////////////////////////////////////////////
//  Shirr
///////////////////////////////////////////////////////////////////////////////////////////
	void Shirr(TYPE p0[], TYPE p1[], TYPE R, TYPE scale, int side)
	{
		TYPE u[3];
		u[0]=p1[0]-p0[0];
		u[1]=p1[1]-p0[1];
		u[2]=p1[2]-p0[2];
		TYPE u_length=Normalize(u);
		TYPE g[4];

		//printf("G: %f, %f, %f, %f\n", g[0], g[1], g[2], g[3]);

		int lower[2];
		int upper[2];
		lower[0]=MAX((MIN(p0[0], p1[0])-R*2)-1, 0);
		lower[1]=MAX((MIN(p0[1], p1[1])-R*2)-1, 0);
		upper[0]=MIN((MAX(p0[0], p1[0])+R*2)+1, nj-1);
		upper[1]=MIN((MAX(p0[1], p1[1])+R*2)+1, ni-1);

		TYPE R2=R*R;
		for(int i=lower[1]; i<=upper[1]; i++)
		for(int j=lower[0]; j<=upper[0]; j++)
		{
			int id=INDEX(i, j);
			if(M[id]==EMPTY_MASK)	continue;

			TYPE pp0[2];
			pp0[0]=j-p0[0];
			pp0[1]=i-p0[1];

			TYPE b=u[0]*pp0[0]+u[1]*pp0[1];
			b=CLAMP(b, 0, u_length);
			TYPE d2=SQR(pp0[0]-b*u[0])+SQR(pp0[1]-b*u[1]);

			if(d2<1 && M[id]!=BOUNDARY_MASK)	M[id]=FIXED_MASK;

			if(d2<R2)
			{
				TYPE cross=u[0]*pp0[1]-u[1]*pp0[0];
				if(side==0 && cross>0)	continue;
				if(side==1 && cross<0)	continue;
				TYPE w=(1-sqrtf(d2/R2));
				w=w*w*w*w;
				w*=10.0f;

				int noise_i=b*u[0]+p0[0];
				int noise_j=b*u[1]+p0[1];

				TYPE _scale=1.4f+sinf(0.24f*b)*0.4f;//+Noise_8[id]*Noise_8[id]*0.6f;

				//_scale=1.8f+sinf(0.1f*b)*0.4f;
				//TYPE _scale=1.2f+sinf(0.24f*b)*0.4f+Noise_8[id]*Noise_8[id]*1.0f;

				g[0]= _scale*u[1]*u[1]+u[0]*u[0];
				g[1]=(_scale-1)*u[0]*u[1];
				g[2]=(_scale-1)*u[0]*u[1];
				g[3]= _scale*u[0]*u[0]+u[1]*u[1];

				//g[0]= 1.1f+Noise_8[id]*Noise_8[id]*0.2f;
				//g[1]= 0;
				//g[2]= 0;
				//g[3]= 1.1f+Noise_8[id]*Noise_8[id]*0.2f;

				G[id*4+0]+=g[0]*w;
				G[id*4+1]+=g[1]*w;
				G[id*4+2]+=w;
				G[id*4+3]+=g[3]*w;

			}
		}
		//printf("G: %f, %f, %f, %f (%f, %f) (%f, %f)\n", g[0], g[1], g[2], g[3], g[0]*g[3]-g[1]*g[2], scale, u[0]*u[0]+u[1]*u[1]);
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Inflate
///////////////////////////////////////////////////////////////////////////////////////////
	void Inflate(TYPE p0[], TYPE p1[], TYPE R, TYPE scale0, TYPE scale1)
	{
		TYPE u[3];
		u[0]=p1[0]-p0[0];
		u[1]=p1[1]-p0[1];
		u[2]=p1[2]-p0[2];
		TYPE u_length=Normalize(u);
		TYPE g[4];
		g[0]= scale0*u[1]*u[1]+scale1*u[0]*u[0];
		g[1]=(scale0-scale1)*u[0]*u[1];
		g[2]=(scale0-scale1)*u[0]*u[1];
		g[3]= scale0*u[0]*u[0]+scale1*u[1]*u[1];

		int lower[2];
		int upper[2];
		lower[0]=MAX((MIN(p0[0], p1[0])-R-2)-1, 0);
		lower[1]=MAX((MIN(p0[1], p1[1])-R-2)-1, 0);
		upper[0]=MIN((MAX(p0[0], p1[0])+R+2)+1, nj-1);
		upper[1]=MIN((MAX(p0[1], p1[1])+R+2)+1, ni-1);

		for(int i=lower[1]; i<=upper[1]; i++)
		for(int j=lower[0]; j<=upper[0]; j++)
		{
			int id=INDEX(i, j);
			if(M[id]==EMPTY_MASK)	continue;

			TYPE pp0[2];
			pp0[0]=j-p0[0];
			pp0[1]=i-p0[1];

			TYPE b=u[0]*pp0[0]+u[1]*pp0[1];
			if(b<0)			continue;
			if(b>u_length)	continue;
			TYPE d2=SQR(pp0[0]-b*u[0])+SQR(pp0[1]-b*u[1]);

			if(d2<R*R*0.5f)
			{
				P[id]=1000.0f;
			}

			if(d2<R*R)
			{
				TYPE w=10.0f;
				TYPE d=sqrtf(d2/(R*R));
				d=1;

				G[id*4+0]+=g[0]*w;
				G[id*4+1]+=g[1]*w;
				G[id*4+2]+=w;
				G[id*4+3]+=w*(1.0f+0.5f*d*d*Noise_8[INDEX(i, j)]);

			}
			else if(d2<(R+1)*(R+1))
				M[id]=FIXED_MASK;
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Full_Inflate
///////////////////////////////////////////////////////////////////////////////////////////
	void Full_Inflate(TYPE radius, TYPE scale)
	{
		air_k=50000000;
		air_k=200000000;
		
		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		{
			int id=INDEX(i, j);
			if(M[id]==EMPTY_MASK)	continue;
				P[id]=3000.0f*Noise_8[INDEX(i/2, j/2)]*Noise_8[INDEX(i/2, j/2)];

				P[id]*=0.1f;
		}
		return;
				
		TYPE*	min_d=new TYPE[ni*nj];
		int*	min_p=new int [ni*nj];

		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		{
			int id=INDEX(i, j);
			min_d[id]=MY_INFINITE;

			G[id*4+0]=1;
			G[id*4+1]=0;
			G[id*4+2]=1;
			G[id*4+3]=1;
		}

		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		{
			//if(M[INDEX(i, j)]<0 && (M[INDEX(i-1, j)]>0 || M[INDEX(i+1, j)]>0 || M[INDEX(i, j-1)]>0 || M[INDEX(i, j+1)]>0))
			if(M[INDEX(i, j)]==FIXED_MASK)
			for(int ii=i-radius-1; ii<=i+radius+1; ii++)
			for(int jj=j-radius-1; jj<=j+radius+1; jj++)
			{
				int id=INDEX(ii, jj);
				TYPE d2=SQR(i-ii)+SQR(j-jj);
				if(d2<radius*radius && d2<min_d[id])
				{
					min_d[id]=d2;
					min_p[id]=INDEX(i, j);
				}
			}		
		}

		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		{
			int id=INDEX(i, j);
			if(min_d[id]!=MY_INFINITE)
			{
				TYPE w=10.0f;
				TYPE d=sqrtf(min_d[id]/(radius*radius));

				if(d>0.5f)	d=0.5f;

				{
					G[id*4+0]+=(1+1.0f*d*d)*w;
					G[id*4+1]-=0;
					G[id*4+2]+=w;
					G[id*4+3]+=(1.0f+0.3f*(1-d)*(1-d)*Noise_8[INDEX(i, j)]*Noise_8[INDEX(i, j)])*w;
				}
			}
		}

		delete[] min_d;
		delete[] min_p;
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Fix
///////////////////////////////////////////////////////////////////////////////////////////
	void Fix(TYPE p0[], TYPE p1[])
	{
		TYPE u[3];
		u[0]=p1[0]-p0[0];
		u[1]=p1[1]-p0[1];
		u[2]=p1[2]-p0[2];
		TYPE u_length=Normalize(u);	

		int lower[2];
		int upper[2];
		lower[0]=MAX((MIN(p0[0], p1[0])-2)-1, 0);
		lower[1]=MAX((MIN(p0[1], p1[1])-2)-1, 0);
		upper[0]=MIN((MAX(p0[0], p1[0])+2)+1, nj-1);
		upper[1]=MIN((MAX(p0[1], p1[1])+2)+1, ni-1);

		for(int i=lower[1]; i<=upper[1]; i++)
		for(int j=lower[0]; j<=upper[0]; j++)
		{
			int id=INDEX(i, j);
			if(M[id]!=VALID_MASK)	continue;

			TYPE pp0[2];
			pp0[0]=j-p0[0];
			pp0[1]=i-p0[1];

			TYPE b=u[0]*pp0[0]+u[1]*pp0[1];
			b=CLAMP(b, 0, u_length);
			TYPE d2=SQR(pp0[0]-b*u[0])+SQR(pp0[1]-b*u[1]);
			if(d2<1)	M[id]=FIXED_MASK;			
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Diamond
///////////////////////////////////////////////////////////////////////////////////////////
	void Diamond()
	{
		TYPE angle=1.0f;
		TYPE freq=0.01f;
		TYPE dot, dist;

		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		{

			int id=INDEX(i, j);
			TYPE min_dist=1.0f;

			if(M[id]==VALID_MASK)
			{
				dot=j*cosf(angle)+i*sin(angle);
				dist=sqrtf(j*j+i*i-dot*dot)*freq;
				dist=dist-(int)dist;
				if(dist>0.5f)	dist=1.0f-dist;
				min_dist=MIN(dist, min_dist);

				dot=-j*cosf(angle)+i*sin(angle);
				dist=sqrtf(j*j+i*i-dot*dot)*freq;
				dist=dist-(int)dist;
				if(dist>0.5f)	dist=1.0f-dist;
				min_dist=MIN(dist, min_dist);

				if(i>600 && min_dist<freq)		M[id]=FIXED_MASK;
			

				P[id]=10.0f;	//1000

				TYPE w=10.0f*(min_dist/0.5f)*Noise_8[INDEX(i/4, j/4)]*Noise_8[INDEX(i/4, j/4)];
				G[id*4+0]+=1.075*w;
				G[id*4+1]-=0;
				G[id*4+2]+=w;
				G[id*4+3]+=1.075*w;
			}
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Expand
///////////////////////////////////////////////////////////////////////////////////////////
	void Expand(TYPE p[], TYPE radius)
	{
		TYPE angle=1.0f;
		TYPE freq=0.01f;
		TYPE dot, dist;

		int lower[2];
		int upper[2];
		lower[0]=MAX((p[0]-radius)-1, 0);
		lower[1]=MAX((p[1]-radius)-1, 0);
		upper[0]=MIN((p[0]+radius)+1, nj-1);
		upper[1]=MIN((p[1]+radius)+1, ni-1);

		dot=p[0]*cosf(angle)+p[1]*sin(angle);
		dist=sqrtf(p[0]*p[0]+p[1]*p[1]-dot*dot)*freq;
		int bi0=(int)dist;
		dot=-p[0]*cosf(angle)+p[1]*sin(angle);
		dist=sqrtf(p[0]*p[0]+p[1]*p[1]-dot*dot)*freq;
		int bi1=(int)dist;

		for(int i=lower[1]; i<=upper[1]; i++)
		for(int j=lower[0]; j<=upper[0]; j++)
		{
			int id=INDEX(i, j);
			if(M[id]==EMPTY_MASK)	continue;

			TYPE min_dist=1.0f;
			dot=j*cosf(angle)+i*sin(angle);
			dist=sqrtf(j*j+i*i-dot*dot)*freq;
			if((int)dist!=bi0)	min_dist=0;
			dist=dist-(int)dist;
			if(dist>0.5f)	dist=1.0f-dist;
			min_dist=MIN(dist, min_dist);

			dot=-j*cosf(angle)+i*sin(angle);
			dist=sqrtf(j*j+i*i-dot*dot)*freq;
			if((int)dist!=bi1)	min_dist=0;
			dist=dist-(int)dist;
			if(dist>0.5f)	dist=1.0f-dist;
			min_dist=MIN(dist, min_dist);
			
			TYPE u[2];
			u[0]=j-p[0];
			u[1]=i-p[1];

			TYPE dist=sqrtf(u[0]*u[0]+u[1]*u[1]);
			if(dist<radius)
			{	
				TYPE w=0.1f*(min_dist/0.5f);
				G[id*4+0]+=2.0f*w;
				G[id*4+1]-=0;
				G[id*4+2]+=w;
				G[id*4+3]+=2.0f*w;
			}				
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Get_Raw_Bending_Data
///////////////////////////////////////////////////////////////////////////////////////////
	/*void Get_Raw_Bending_Data(TYPE data[])
	{
		memset(data, 0, sizeof(TYPE)*number*12);

		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)		
		{
			int  ev[4][2];
			TYPE ek[4];

			ev[0][0]=i;		ev[0][1]=j;		ek[0]= 1/h;
			ev[1][0]=i;		ev[1][1]=j+1;	ek[1]= 1/h;
			ev[2][0]=i-1;	ev[2][1]=j;		ek[2]=-1/h;
			ev[3][0]=i+1;	ev[3][1]=j+1;	ek[3]=-1/h;

			if(Is_Valid(ev[0][0], ev[0][1]) && Is_Valid(ev[1][0], ev[1][1]) && Is_Valid(ev[2][0], ev[2][1]) && Is_Valid(ev[3][0], ev[3][1]))
			{
				for(int v0=0; v0<4; v0++)	for(int v1=0; v1<4; v1++)	if(v0!=v1)
					Add_Bend_O(ev[v0][0], ev[v0][1], ev[v1][0], ev[v1][1], -ek[v0]*ek[v1], data);
			}
		
			ev[0][0]=i;		ev[0][1]=j;		ek[0]= 1/h;
			ev[1][0]=i+1;	ev[1][1]=j;		ek[1]= 1/h;
			ev[2][0]=i;		ev[2][1]=j-1;	ek[2]=-1/h;
			ev[3][0]=i+1;	ev[3][1]=j+1;	ek[3]=-1/h;
			if(Is_Valid(ev[0][0], ev[0][1]) && Is_Valid(ev[1][0], ev[1][1]) && Is_Valid(ev[2][0], ev[2][1]) && Is_Valid(ev[3][0], ev[3][1]))
			{
				for(int v0=0; v0<4; v0++)	for(int v1=0; v1<4; v1++)	if(v0!=v1)
					Add_Bend_O(ev[v0][0], ev[v0][1], ev[v1][0], ev[v1][1], -ek[v0]*ek[v1], data);
			}

			ev[0][0]=i;		ev[0][1]=j;		ek[0]=-2/h;
			ev[1][0]=i+1;	ev[1][1]=j+1;	ek[1]=-2/h;
			ev[2][0]=i+1;	ev[2][1]=j;		ek[2]= 2/h;
			ev[3][0]=i;		ev[3][1]=j+1;	ek[3]= 2/h;		
			if(Is_Valid(ev[0][0], ev[0][1]) && Is_Valid(ev[1][0], ev[1][1]) && Is_Valid(ev[2][0], ev[2][1]) && Is_Valid(ev[3][0], ev[3][1]))
			{
				for(int v0=0; v0<4; v0++)	for(int v1=0; v1<4; v1++)	if(v0!=v1)
					Add_Bend_O(ev[v0][0], ev[v0][1], ev[v1][0], ev[v1][1], -ek[v0]*ek[v1], data);
			}
		}
	}

	void Get_Raw_Bending_Data3(TYPE data[])
	{
		memset(data, 0, sizeof(TYPE)*number*12);

		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)		
		{
			int  ev[4][2];
			TYPE ek[4];

			if((i+j)%2==0)
			{
				ev[0][0]=i;		ev[0][1]=j;		ek[0]= 2/h;
				ev[1][0]=i;		ev[1][1]=j-1;	ek[1]= 0/h;
				ev[2][0]=i-1;	ev[2][1]=j;		ek[2]=-1/h;
				ev[3][0]=i+1;	ev[3][1]=j;		ek[3]=-1/h;

				if(Is_Valid(ev[0][0], ev[0][1]) && Is_Valid(ev[1][0], ev[1][1]) && Is_Valid(ev[2][0], ev[2][1]) && Is_Valid(ev[3][0], ev[3][1]))
				{
					for(int v0=0; v0<4; v0++)	for(int v1=0; v1<4; v1++)	if(v0!=v1)
						Add_Bend_O(ev[v0][0], ev[v0][1], ev[v1][0], ev[v1][1], -ek[v0]*ek[v1], data);
				}

				ev[0][0]=i;		ev[0][1]=j;		ek[0]= 2/h;
				ev[1][0]=i;		ev[1][1]=j+1;	ek[1]= 0/h;
				ev[2][0]=i-1;	ev[2][1]=j;		ek[2]=-1/h;
				ev[3][0]=i+1;	ev[3][1]=j;		ek[3]=-1/h;

				if(Is_Valid(ev[0][0], ev[0][1]) && Is_Valid(ev[1][0], ev[1][1]) && Is_Valid(ev[2][0], ev[2][1]) && Is_Valid(ev[3][0], ev[3][1]))
				{
					for(int v0=0; v0<4; v0++)	for(int v1=0; v1<4; v1++)	if(v0!=v1)
						Add_Bend_O(ev[v0][0], ev[v0][1], ev[v1][0], ev[v1][1], -ek[v0]*ek[v1], data);
				}

				ev[0][0]=i;		ev[0][1]=j;		ek[0]= 2/h;
				ev[1][0]=i-1;	ev[1][1]=j;		ek[1]= 0/h;
				ev[2][0]=i;		ev[2][1]=j-1;	ek[2]=-1/h;
				ev[3][0]=i;		ev[3][1]=j+1;	ek[3]=-1/h;

				if(Is_Valid(ev[0][0], ev[0][1]) && Is_Valid(ev[1][0], ev[1][1]) && Is_Valid(ev[2][0], ev[2][1]) && Is_Valid(ev[3][0], ev[3][1]))
				{
					for(int v0=0; v0<4; v0++)	for(int v1=0; v1<4; v1++)	if(v0!=v1)
						Add_Bend_O(ev[v0][0], ev[v0][1], ev[v1][0], ev[v1][1], -ek[v0]*ek[v1], data);
				}

				ev[0][0]=i;		ev[0][1]=j;		ek[0]= 2/h;
				ev[1][0]=i+1;	ev[1][1]=j;		ek[1]= 0/h;
				ev[2][0]=i;		ev[2][1]=j-1;	ek[2]=-1/h;
				ev[3][0]=i;		ev[3][1]=j+1;	ek[3]=-1/h;

				if(Is_Valid(ev[0][0], ev[0][1]) && Is_Valid(ev[1][0], ev[1][1]) && Is_Valid(ev[2][0], ev[2][1]) && Is_Valid(ev[3][0], ev[3][1]))
				{
					for(int v0=0; v0<4; v0++)	for(int v1=0; v1<4; v1++)	if(v0!=v1)
						Add_Bend_O(ev[v0][0], ev[v0][1], ev[v1][0], ev[v1][1], -ek[v0]*ek[v1], data);
				}
			}

			ev[0][0]=i;		ev[0][1]=j;		ek[0]=-2/h;
			ev[1][0]=i+1;	ev[1][1]=j+1;	ek[1]=-2/h;
			ev[2][0]=i+1;	ev[2][1]=j;		ek[2]= 2/h;
			ev[3][0]=i;		ev[3][1]=j+1;	ek[3]= 2/h;		
			if(Is_Valid(ev[0][0], ev[0][1]) && Is_Valid(ev[1][0], ev[1][1]) && Is_Valid(ev[2][0], ev[2][1]) && Is_Valid(ev[3][0], ev[3][1]))
			{
				for(int v0=0; v0<4; v0++)	for(int v1=0; v1<4; v1++)	if(v0!=v1)
					Add_Bend_O(ev[v0][0], ev[v0][1], ev[v1][0], ev[v1][1], -ek[v0]*ek[v1], data);
			}
		}
	}

	void Get_Raw_Bending_Data2(TYPE data[])
	{
		memset(data, 0, sizeof(TYPE)*number*12);

		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)		
		{
			int  ev[4][2];

			ev[0][0]=i;		ev[0][1]=j;		
			ev[1][0]=i;		ev[1][1]=j+1;	
			ev[2][0]=i-1;	ev[2][1]=j;		
			ev[3][0]=i+1;	ev[3][1]=j+1;		
			Add_Bend_O(ev, data);

			ev[0][0]=i;		ev[0][1]=j;
			ev[1][0]=i+1;	ev[1][1]=j;
			ev[2][0]=i;		ev[2][1]=j-1;
			ev[3][0]=i+1;	ev[3][1]=j+1;
			Add_Bend_O(ev, data);

			ev[0][0]=i;		ev[0][1]=j;
			ev[1][0]=i+1;	ev[1][1]=j+1;
			ev[2][0]=i+1;	ev[2][1]=j;
			ev[3][0]=i;		ev[3][1]=j+1;	
			Add_Bend_O(ev, data);
		}
	}

	void Add_Bend_O(int i, int j, int i1, int j1, TYPE value, TYPE data[])
	{
		for(int n=0; n<12; n++)
		{
			int oi, oj;
				 if(n==0)	{oi=-1; oj= 0;}
			else if(n==1)	{oi= 0; oj=-1;}
			else if(n==2)	{oi= 1; oj=-1;}
			else if(n==3)	{oi= 1; oj= 0;}
			else if(n==4)	{oi= 0; oj= 1;}
			else if(n==5)	{oi=-1; oj= 1;}
			else if(n==6)	{oi=-1; oj=-1;}
			else if(n==7)	{oi= 1; oj= 1;}
			else if(n==8)	{oi=-2; oj= 0;}
			else if(n==9)	{oi= 2; oj= 0;}
			else if(n==10)	{oi= 0; oj=-2;}
			else if(n==11)	{oi= 0; oj= 2;}
			if(i+oi==i1 && j+oj==j1)
			{ 
				data[n*number+INDEX(i, j)]+=value;
				return;
			}
		}
		printf("ERROR: Failed to determine the spot in Bend_O.\n");
	}

	inline TYPE Cotangent(TYPE a, TYPE b, TYPE c)
	{
		TYPE cosine=(a*a+b*b-c*c)/(2*a*b);
		return cosine/sqrt(1-cosine*cosine);
	}

	inline TYPE Area(TYPE a, TYPE b, TYPE c)	
	{
		TYPE p=(a+b+c)/2;
		return sqrt(p*(p-a)*(p-b)*(p-c));
	}

	void Add_Bend_O(int V[4][2], TYPE data[])
	{
		if(!Is_Valid(V[0][0], V[0][1]))	return;
		if(!Is_Valid(V[1][0], V[1][1]))	return;
		if(!Is_Valid(V[2][0], V[2][1]))	return;
		if(!Is_Valid(V[3][0], V[3][1]))	return;

		TYPE L0=Spring_Length(V[0][0], V[0][1], V[1][0], V[1][1], G, M, ni, nj, h);
		TYPE L1=Spring_Length(V[0][0], V[0][1], V[2][0], V[2][1], G, M, ni, nj, h);
		TYPE L2=Spring_Length(V[0][0], V[0][1], V[3][0], V[3][1], G, M, ni, nj, h);
		TYPE L3=Spring_Length(V[1][0], V[1][1], V[2][0], V[2][1], G, M, ni, nj, h);
		TYPE L4=Spring_Length(V[1][0], V[1][1], V[3][0], V[3][1], G, M, ni, nj, h);

		TYPE c01=Cotangent(L0, L1, L3);
		TYPE c02=Cotangent(L0, L2, L4);
		TYPE c03=Cotangent(L0, L3, L1);
		TYPE c04=Cotangent(L0, L4, L2);
		TYPE area=Area(L0, L1, L3)+Area(L0, L2, L4);

		TYPE k[4]={c03+c04, c01+c02, -c01-c03, -c02-c04};
		
		//printf("V: %d, %d; %d, %d; %d, %d; %d, %d\n",
		//	V[0][0], V[0][1],
		//	V[1][0], V[1][1],
		//	V[2][0], V[2][1],
		//	V[3][0], V[3][1]);

		//printf("K: %f, %f, %f, %f\n", k[0]/sqrt(area), k[1]/sqrt(area), k[2]/sqrt(area), k[3]/sqrt(area));
		//printf("? %f, %f, %f, %f\n", 1/h, 1/h, -1/h, -1/h);

		for(int v0=0; v0<4; v0++)	
		for(int v1=0; v1<4; v1++)
		if(v0!=v1)
		{
			Add_Bend_O(V[v0][0], V[v0][1], V[v1][0], V[v1][1], -k[v0]*k[v1]/area, data);
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Compress_Bending_Data
///////////////////////////////////////////////////////////////////////////////////////////
	int Compress_Bending_Data(int ID[], TYPE compact_data[][12], TYPE data[])
	{
		int compact_number=0;
		for(int i=0; i<number; i++)
		{
			int bid=0;
			for(bid=0; bid<compact_number; bid++)
			{
				if(	compact_data[bid][ 0]==data[ 0*number+i] &&
					compact_data[bid][ 1]==data[ 1*number+i] &&
					compact_data[bid][ 2]==data[ 2*number+i] &&
					compact_data[bid][ 3]==data[ 3*number+i] &&
					compact_data[bid][ 4]==data[ 4*number+i] &&
					compact_data[bid][ 5]==data[ 5*number+i] &&
					compact_data[bid][ 6]==data[ 6*number+i] &&
					compact_data[bid][ 7]==data[ 7*number+i] &&
					compact_data[bid][ 8]==data[ 8*number+i] &&
					compact_data[bid][ 9]==data[ 9*number+i] &&
					compact_data[bid][10]==data[10*number+i] &&
					compact_data[bid][11]==data[11*number+i])
					break;
			}
			if(bid==compact_number)
			{
				compact_data[bid][ 0]=data[ 0*number+i];
				compact_data[bid][ 1]=data[ 1*number+i];
				compact_data[bid][ 2]=data[ 2*number+i];
				compact_data[bid][ 3]=data[ 3*number+i];
				compact_data[bid][ 4]=data[ 4*number+i];
				compact_data[bid][ 5]=data[ 5*number+i];
				compact_data[bid][ 6]=data[ 6*number+i];
				compact_data[bid][ 7]=data[ 7*number+i];
				compact_data[bid][ 8]=data[ 8*number+i];
				compact_data[bid][ 9]=data[ 9*number+i];
				compact_data[bid][10]=data[10*number+i];
				compact_data[bid][11]=data[11*number+i];
				compact_number++;
			}
			ID[i]=bid;
		}
		return compact_number;
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Verify_Compact_Bending_Data
///////////////////////////////////////////////////////////////////////////////////////////
	void Verify_Compact_Bending_Data(int ID[], TYPE compact_data[][12], TYPE data[])
	{
		for(int i=0; i<number; i++)
		{
			int bid=ID[i];
			
			if(	fabsf(compact_data[bid][ 0]-data[ 0*number+i])>fabsf(data[ 0*number+i])*1e-6f ||
				fabsf(compact_data[bid][ 1]-data[ 1*number+i])>fabsf(data[ 1*number+i])*1e-6f ||
				fabsf(compact_data[bid][ 2]-data[ 2*number+i])>fabsf(data[ 2*number+i])*1e-6f ||
				fabsf(compact_data[bid][ 3]-data[ 3*number+i])>fabsf(data[ 3*number+i])*1e-6f ||
				fabsf(compact_data[bid][ 4]-data[ 4*number+i])>fabsf(data[ 4*number+i])*1e-6f ||
				fabsf(compact_data[bid][ 5]-data[ 5*number+i])>fabsf(data[ 5*number+i])*1e-6f ||
				fabsf(compact_data[bid][ 6]-data[ 6*number+i])>fabsf(data[ 6*number+i])*1e-6f ||
				fabsf(compact_data[bid][ 7]-data[ 7*number+i])>fabsf(data[ 7*number+i])*1e-6f ||
				fabsf(compact_data[bid][ 8]-data[ 8*number+i])>fabsf(data[ 8*number+i])*1e-6f ||
				fabsf(compact_data[bid][ 9]-data[ 9*number+i])>fabsf(data[ 9*number+i])*1e-6f ||
				fabsf(compact_data[bid][10]-data[10*number+i])>fabsf(data[10*number+i])*1e-6f ||
				fabsf(compact_data[bid][11]-data[11*number+i])>fabsf(data[11*number+i])*1e-6f )
			{
				printf("a %d %d: %f, %f, %f; %f, %f, %f; %f, %f, %f; %f, %f, %f\n", i, bid,
					compact_data[bid][ 0], compact_data[bid][ 1], compact_data[bid][ 2], 
					compact_data[bid][ 3], compact_data[bid][ 4], compact_data[bid][ 5],
					compact_data[bid][ 6], compact_data[bid][ 7], compact_data[bid][ 8],
					compact_data[bid][ 9], compact_data[bid][10], compact_data[bid][11]);

				printf("b %d: %f, %f, %f; %f, %f, %f; %f, %f, %f; %f, %f, %f\n", bid,
					data[ 0*number+i], data[ 1*number+i], data[ 2*number+i],
					data[ 3*number+i], data[ 4*number+i], data[ 5*number+i],
					data[ 6*number+i], data[ 7*number+i], data[ 8*number+i],
					data[ 9*number+i], data[10*number+i], data[11*number+i]);

				getchar();
			}
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Compact_Bending_Data
///////////////////////////////////////////////////////////////////////////////////////////
	int Compact_Bending_Data(int ID[], TYPE compact_data[][12])
	{
		TIMER timer;
		int codes[256];
		int code_number=1;
		codes[0]=(1<<12)-1;

		//States labels out the nodes close to the boundary, where irregular codes may occur.
		int* states=new int[number]{};		
		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		if(M[INDEX(i, j)])
		{
			if(	i!=0	&& !M[INDEX(i-1, j)] ||
				j!=0	&& !M[INDEX(i, j-1)] ||
				i!=ni-1 && !M[INDEX(i+1, j)] ||
				j!=nj-1 && !M[INDEX(i, j+1)] )
			{

				for(int ii=-1; ii<=1; ii++)
				for(int jj=-1; jj<=1; jj++)
					if(Is_Valid(i+ii, j+jj))
						states[INDEX(i+ii, j+jj)]=1;
			}
		}
		
		memset(ID, 0, sizeof(int)*number);
		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		if(states[INDEX(i, j)])
		{
			int code=0;
			for(int n=0; n<12; n++)
			{
				code*=2;
				int oi, oj;
					 if(n==0)	{oi=-1; oj= 0;}
				else if(n==1)	{oi= 0; oj=-1;}
				else if(n==2)	{oi= 1; oj=-1;}
				else if(n==3)	{oi= 1; oj= 0;}
				else if(n==4)	{oi= 0; oj= 1;}
				else if(n==5)	{oi=-1; oj= 1;}
				else if(n==6)	{oi=-1; oj=-1;}
				else if(n==7)	{oi= 1; oj= 1;}
				else if(n==8)	{oi=-2; oj=-1;}
				else if(n==9)	{oi=-1; oj=-2;}
				else if(n==10)	{oi= 2; oj= 1;}
				else if(n==11)	{oi= 1; oj= 2;}
				if(Is_Valid(i+oi, j+oj))	code++;
			}
			int id=INDEX(i, j);

			int cid=0;
			for(cid=0; cid<code_number; cid++)
				if(codes[cid]==code)	break;
			if(cid==code_number)
			{
				codes[cid]=code;
				code_number++;
			}
			ID[id]=cid;
		}
		delete[] states;

		for(int i=0; i<code_number; i++)
		{

			Code_2_Data(codes[i], &compact_data[i][0]);
			//printf("%d: %d: %f, %f, %f; %f, %f, %f; %f, %f, %f; %f, %f, %f\n", i, codes[i],
			//	new_compact_bend_data[i][ 0], new_compact_bend_data[i][ 1], new_compact_bend_data[i][ 2], 
			//	new_compact_bend_data[i][ 3], new_compact_bend_data[i][ 4], new_compact_bend_data[i][ 5], 
			//	new_compact_bend_data[i][ 6], new_compact_bend_data[i][ 7], new_compact_bend_data[i][ 8], 
			//	new_compact_bend_data[i][ 9], new_compact_bend_data[i][10], new_compact_bend_data[i][11]);
		}

		//Post-processing: Different codes may share the same data. Remove such redundancy.
		//First build map0 that detects identical data.
		int map0[256];
		for(int c=0; c<code_number; c++)	map0[c]=c;
		for(int c=0; c<code_number; c++)
		{
			if(map0[c]!=c)	continue;
			for(int cc=c+1; cc<code_number; cc++)
			{
				if(	compact_data[c][ 0]==compact_data[cc][ 0] && compact_data[c][ 1]==compact_data[cc][ 1] &&
					compact_data[c][ 2]==compact_data[cc][ 2] && compact_data[c][ 3]==compact_data[cc][ 3] &&
					compact_data[c][ 4]==compact_data[cc][ 4] && compact_data[c][ 5]==compact_data[cc][ 5] &&
					compact_data[c][ 6]==compact_data[cc][ 6] && compact_data[c][ 7]==compact_data[cc][ 7] &&
					compact_data[c][ 8]==compact_data[cc][ 8] && compact_data[c][ 9]==compact_data[cc][ 9] &&
					compact_data[c][10]==compact_data[cc][10] && compact_data[c][11]==compact_data[cc][11])				
					map0[cc]=c;				
			}
		}
		//Second, build the map for collapsing.
		int map1[256];
		int compact_bend_number=0;
		for(int c=0; c<code_number; c++)
		if(map0[c]==c)	
		{
			map1[c]=compact_bend_number++;			
			for(int n=0; n<12; n++)
				compact_data[map1[c]][n]=compact_data[c][n];
		}
		//Third, apply map0 and map1.
		for(int id=0; id<number; id++)
			ID[id]=map1[map0[ID[id]]];

		return compact_bend_number;
	}
	
	void Code_2_Data(int code, TYPE data[12])
	{
		int map[5][5]{};

		map[2][2]=1;
		for(int n=0; n<12; n++)
		{
			int oi, oj;
				 if(n==11)	{oi=-1; oj= 0;}
			else if(n==10)	{oi= 0; oj=-1;}
			else if(n==9)	{oi= 1; oj=-1;}
			else if(n==8)	{oi= 1; oj= 0;}
			else if(n==7)	{oi= 0; oj= 1;}
			else if(n==6)	{oi=-1; oj= 1;}
			else if(n==5)	{oi=-1; oj=-1;}
			else if(n==4)	{oi= 1; oj= 1;}
			else if(n==3)	{oi=-2; oj=-1;}
			else if(n==2)	{oi=-1; oj=-2;}
			else if(n==1)	{oi= 2; oj= 1;}
			else if(n==0)	{oi= 1; oj= 2;}
		
			if(code%2==1)	map[oi+2][oj+2]=1;			
			else			map[oi+2][oj+2]=0;
			code/=2;
		}

		memset(data, 0, sizeof(TYPE)*12);
		Insert_Data(2, 2, 2, 1, 1, 1, 3, 2, -1/(h*h), map, data);
		Insert_Data(2, 2, 0, 1, 1, 1, 1, 2, -1/(h*h), map, data);
		Insert_Data(2, 2, 2, 3, 1, 2, 3, 3, -1/(h*h), map, data);
		Insert_Data(2, 2, 4, 3, 3, 2, 3, 3, -1/(h*h), map, data);
		Insert_Data(2, 2, 1, 2, 1, 1, 2, 3, -1/(h*h), map, data);
		Insert_Data(2, 2, 1, 0, 1, 1, 2, 1, -1/(h*h), map, data);
		Insert_Data(2, 2, 3, 4, 2, 3, 3, 3, -1/(h*h), map, data);
		Insert_Data(2, 2, 3, 2, 2, 1, 3, 3, -1/(h*h), map, data);
		Insert_Data(2, 2, 1, 1, 2, 1, 1, 2, -4/(h*h), map, data);
		Insert_Data(2, 2, 1, 3, 1, 2, 2, 3, -4/(h*h), map, data);
		Insert_Data(2, 2, 3, 1, 2, 1, 3, 2, -4/(h*h), map, data);		
		Insert_Data(2, 2, 3, 3, 3, 2, 2, 3, -4/(h*h), map, data);
	}

	void Insert_Data(int i0, int j0, int i1, int j1, int i2, int j2, int i3, int j3, TYPE w, int map[5][5], TYPE data[12])
	{
		if(map[i0][j0]==0)	return;
		if(map[i1][j1]==0)	return;
		if(map[i2][j2]==0)	return;
		if(map[i3][j3]==0)	return;		
		for(int n=0; n<12; n++)
		{
			int oi, oj;
				 if(n==0)	{oi=-1; oj= 0;}
			else if(n==1)	{oi= 0; oj=-1;}
			else if(n==2)	{oi= 1; oj=-1;}
			else if(n==3)	{oi= 1; oj= 0;}
			else if(n==4)	{oi= 0; oj= 1;}
			else if(n==5)	{oi=-1; oj= 1;}
			else if(n==6)	{oi=-1; oj=-1;}
			else if(n==7)	{oi= 1; oj= 1;}
			else if(n==8)	{oi=-2; oj=-1;}
			else if(n==9)	{oi=-1; oj=-2;}
			else if(n==10)	{oi= 2; oj= 1;}
			else if(n==11)	{oi= 1; oj= 2;}
			if(i0+oi==i1 && j0+oj==j1)	data[n]+=w;
			if(i0+oi==i2 && j0+oj==j2)	data[n]-=w;
			if(i0+oi==i3 && j0+oj==j3)	data[n]-=w;			
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Is_Valid
///////////////////////////////////////////////////////////////////////////////////////////
	inline bool Is_Valid(int id)
	{
		return Is_Valid(id/nj, id%nj);
	}

	inline bool Is_Valid(int i, int j)
	{
		if(i<0)		return false;
		if(j<0)		return false;
		if(i>=ni)	return false;
		if(j>=nj)	return false;

		return M[INDEX(i, j)];
		//return true;
	}*/
	
///////////////////////////////////////////////////////////////////////////////////////////
//  Update
///////////////////////////////////////////////////////////////////////////////////////////
	void Update(TYPE next_X[], int i, int j, TYPE alpha)
	{
		int id=INDEX(i, j);
		if(M[id]<=0)	return;
					
		TYPE f[3]{};
		TYPE d[3]{};
		for(int n=0; n<12; n++)
		{
			int oi, oj;
				 if(n==0)	{oi=-1; oj= 0;}
			else if(n==1)	{oi= 0; oj=-1;}
			else if(n==2)	{oi= 1; oj=-1;}
			else if(n==3)	{oi= 1; oj= 0;}
			else if(n==4)	{oi= 0; oj= 1;}
			else if(n==5)	{oi=-1; oj= 1;}
			else if(n==6)	{oi=-1; oj=-1;}
			else if(n==7)	{oi= 1; oj= 1;}
			else if(n==8)	{oi=-2; oj=-1;}
			else if(n==9)	{oi=-1; oj=-2;}
			else if(n==10)	{oi= 2; oj= 1;}
			else if(n==11)	{oi= 1; oj= 2;}
			if(i+oi<0 || i+oi>=ni)	continue;
			if(j+oj<0 || j+oj>=nj)	continue;
			int nid=INDEX(i+oi, j+oj);
			TYPE u[3];
			u[0]=X[id*3+0]-X[nid*3+0];
			u[1]=X[id*3+1]-X[nid*3+1];
			u[2]=X[id*3+2]-X[nid*3+2];
			
			TYPE v=0;				
			//spring
			if(n<6)	v=spring_data[n*number+id];
			if(v)
			{
				TYPE ratio, k[3];
				TYPE planar_k = spring_k/v;		//Young's modulus fix				
				TYPE inv_m2=1.0f/(u[0]*u[0]+u[1]*u[1]+u[2]*u[2]);

				ratio=v*sqrtf(inv_m2);
				f[0]-=planar_k*(1-ratio)*u[0];
				f[1]-=planar_k*(1-ratio)*u[1];
				f[2]-=planar_k*(1-ratio)*u[2];

				k[0]=(fmaxf(1-ratio, 0.0f)+ratio*u[0]*u[0]*inv_m2)*planar_k;
				k[1]=(fmaxf(1-ratio, 0.0f)+ratio*u[1]*u[1]*inv_m2)*planar_k;
				k[2]=(fmaxf(1-ratio, 0.0f)+ratio*u[2]*u[2]*inv_m2)*planar_k;
				d[0]-=k[0];
				d[1]-=k[1];
				d[2]-=k[2];
			}
			//Bending
			//v=bend_data[n*number+id];
			v=compact_bend_data[bend_ID[id]][n];
			if(v)
			{
				f[0]-=v*bending_k*u[0];
				f[1]-=v*bending_k*u[1];
				f[2]-=v*bending_k*u[2];
				d[0]-=v*bending_k;
				d[1]-=v*bending_k;
				d[2]-=v*bending_k;
			}
		}

		//f[0]+=fixed_W[id*3+0]*(fixed_X[id*3+0]-X[id*3+0]);
		//f[1]+=fixed_W[id*3+1]*(fixed_X[id*3+1]-X[id*3+1]);
		//f[2]+=fixed_W[id*3+2]*(fixed_X[id*3+2]-X[id*3+2]);
		//d[0]-=fixed_W[id*3+0];
		//d[1]-=fixed_W[id*3+1];
		//d[2]-=fixed_W[id*3+2];

		next_X[id*3+0]=X[id*3+0];
		next_X[id*3+1]=X[id*3+1];
		next_X[id*3+2]=X[id*3+2];

		if(d[0])	next_X[id*3+0]-=alpha*f[0]/d[0];
		if(d[1])	next_X[id*3+1]-=alpha*f[1]/d[1];
		if(d[2])	next_X[id*3+2]-=alpha*f[2]/d[2];
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Energy
///////////////////////////////////////////////////////////////////////////////////////////
	TYPE Energy()
	{
		TYPE energy=0;

		for(int i=0; i<ni; i++)
		for(int j=0; j<nj; j++)
		{
			int id=INDEX(i, j);
			if(M[id]==EMPTY_MASK)	continue;

			TYPE f[3]{};
			
			for(int n=0; n<12; n++)
			{
				int oi, oj;
					 if(n==0)	{oi=-1; oj= 0;}
				else if(n==1)	{oi= 0; oj=-1;}
				else if(n==2)	{oi= 1; oj=-1;}
				else if(n==3)	{oi= 1; oj= 0;}
				else if(n==4)	{oi= 0; oj= 1;}
				else if(n==5)	{oi=-1; oj= 1;}
				else if(n==6)	{oi=-1; oj=-1;}
				else if(n==7)	{oi= 1; oj= 1;}
				else if(n==8)	{oi=-2; oj=-1;}
				else if(n==9)	{oi=-1; oj=-2;}
				else if(n==10)	{oi= 2; oj= 1;}
				else if(n==11)	{oi= 1; oj= 2;}
				if(i+oi<0 || i+oi>=ni)	continue;
				if(j+oj<0 || j+oj>=nj)	continue;
				int nid=INDEX(i+oi, j+oj);
				TYPE u[3];
				u[0]=X[id*3+0]-X[nid*3+0];
				u[1]=X[id*3+1]-X[nid*3+1];
				u[2]=X[id*3+2]-X[nid*3+2];	
					
				TYPE v=0;
				//spring
				if(n<6)	v=spring_data[n*number+id];
				if(v)
				{
					TYPE planar_k = spring_k/v;		// Young's modulus fix
					energy+=0.25f*planar_k*(v-Magnitude(u))*(v-Magnitude(u));
				}	
				//Bending
				//v=bend_data[n*number+id];
				v=compact_bend_data[bend_ID[id]][n];
				if(v)
				{
					f[0]-=v*bending_k*u[0];
					f[1]-=v*bending_k*u[1];
					f[2]-=v*bending_k*u[2];
				}
			}
			energy-=0.5f*X[INDEX(i, j)*3+0]*f[0];
			energy-=0.5f*X[INDEX(i, j)*3+1]*f[1];
			energy-=0.5f*X[INDEX(i, j)*3+2]*f[2];

			//energy+=0.5f*fixed_W[id*3+0]*(fixed_X[id*3+0]-X[id*3+0])*(fixed_X[id*3+0]-X[id*3+0]);
			//energy+=0.5f*fixed_W[id*3+1]*(fixed_X[id*3+1]-X[id*3+1])*(fixed_X[id*3+1]-X[id*3+1]);
			//energy+=0.5f*fixed_W[id*3+2]*(fixed_X[id*3+2]-X[id*3+2])*(fixed_X[id*3+2]-X[id*3+2]);
		}

		return energy;
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Update
///////////////////////////////////////////////////////////////////////////////////////////
	void Update(int iter=32)
	{
		TYPE alpha=0.4f;//8f;
		TYPE rho=0.92f;	//0.992f
		TYPE omega=1.0f;

		memcpy(next_X, X, sizeof(TYPE)*number*3);
		printf("start energy: %f (%d)\n", Energy(), number/(BLOCK_SIZE*BLOCK_SIZE));
		
		for(int l=0; l<iter; l++)
		{
			if(l<8)			omega=1;
			else if(l==8)	omega=2/(2-rho*rho);
			else			omega=4/(4-rho*rho*omega);
		
			/*if(0)
			for(int c=0; c<c_number; c++)
			{
				for(int il=0; il<8; il++)
				{
					for(int i=0; i<ni; i++)
					for(int j=0; j<nj; j++)
						Compute_F(i, j);
					for(int i=0; i<number; i++)	
					if(C[i]==c)
					{
						X[i*3+0]-=alpha*F[i*3+0]/D[i*3+0];
						X[i*3+1]-=alpha*F[i*3+1]/D[i*3+1];
						X[i*3+2]-=alpha*F[i*3+2]/D[i*3+2];
					}
				}
			}*/

			for(int bi=0; bi<ni/BLOCK_SIZE; bi++)
			for(int bj=0; bj<nj/BLOCK_SIZE; bj++)
			{
				//for(int il=0; il<8; il++)
				if(block_state[bi*(nj/BLOCK_SIZE)+bj])
				{
					for(int ii=0; ii<BLOCK_SIZE; ii++)
					for(int jj=0; jj<BLOCK_SIZE; jj++)
						Update(next_X, bi*BLOCK_SIZE+ii, bj*BLOCK_SIZE+jj, alpha);
				}
			}
			
			for(int id=0; id<number*3; id++)	
			{
				next_X[id]+=(omega-1)*(next_X[id]-prev_X[id]);
				prev_X[id]=curr_X[id];
				curr_X[id]=next_X[id];
					 X[id]=next_X[id];
			}

			printf("%d: %f (%d)\n", l, Energy(), number/(BLOCK_SIZE*BLOCK_SIZE));
		}
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Read_File
///////////////////////////////////////////////////////////////////////////////////////////
	bool Read_File(const char *filename)
	{
		std::fstream input; 
		input.open(filename,std::ios::in|std::ios::binary);
		if(!input.is_open())	return false;		
		Read_Binaries(input, M, number);
		
		int data_length=0;
		for(int id=0; id<ni*nj; id++)
			if(M[id]!=EMPTY_MASK)	data_length++;

		TYPE* data=new TYPE[data_length*8];			
		Read_Binaries(input, data, data_length*8);

		for(int id=0, ptr=0; id<ni*nj; id++)
		if(M[id]!=EMPTY_MASK)	
		{
			X[id*3+0]=data[ptr*8+0];
			X[id*3+1]=data[ptr*8+1];
			X[id*3+2]=data[ptr*8+2];
			P[id    ]=data[ptr*8+3];
			G[id*4+0]=data[ptr*8+4];
			G[id*4+1]=data[ptr*8+5];
			G[id*4+2]=data[ptr*8+6];
			G[id*4+3]=data[ptr*8+7];
			ptr++;
		}
		delete[] data;

		input.close();
		return true;
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Write_File
///////////////////////////////////////////////////////////////////////////////////////////
	bool Write_File(const char *file_name)
	{
		std::fstream output; 
		output.open(file_name,std::ios::out|std::ios::binary);
		if(!output.is_open())	return false;
		Write_Binaries(output, M, number);

		int data_length=0;
		for(int id=0; id<ni*nj; id++)
			if(M[id]!=EMPTY_MASK)	data_length++;

		TYPE* data=new TYPE[data_length*8];		
		for(int id=0, ptr=0; id<ni*nj; id++)
		if(M[id]!=EMPTY_MASK)	
		{
			data[ptr*8+0]=X[id*3+0];
			data[ptr*8+1]=X[id*3+1];
			data[ptr*8+2]=X[id*3+2];
			data[ptr*8+3]=P[id];
			data[ptr*8+4]=G[id*4+0];
			data[ptr*8+5]=G[id*4+1];
			data[ptr*8+6]=G[id*4+2];
			data[ptr*8+7]=G[id*4+3];
			ptr++;
		}
		Write_Binaries(output, data, data_length*8);
		delete[] data;

		output.close();
		return true;
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Write_G_Map
///////////////////////////////////////////////////////////////////////////////////////////
	bool Write_G_Map(const char *file_name)
	{
		std::fstream output; 
		output.open(file_name,std::ios::out|std::ios::binary);
		if(!output.is_open())	return false;
		Write_Binaries(output, M, number);

		int data_length=0;
		for(int id=0; id<ni*nj; id++)
			if(M[id]!=EMPTY_MASK)	data_length++;

		TYPE* data=new TYPE[data_length*4];		
		for(int id=0, ptr=0; id<ni*nj; id++)
		if(M[id]!=EMPTY_MASK)	
		{
			data[ptr*4+0]=G[id*4+0];
			data[ptr*4+1]=G[id*4+1];
			data[ptr*4+2]=G[id*4+2];
			data[ptr*4+3]=G[id*4+3];
			ptr++;
		}
		Write_Binaries(output, data, data_length*4);
		delete[] data;

		output.close();
		return true;
	}

///////////////////////////////////////////////////////////////////////////////////////////
//  Read_G_Map
///////////////////////////////////////////////////////////////////////////////////////////
	bool Read_G_Map(const char *filename)
	{
		std::fstream input; 
		input.open(filename,std::ios::in|std::ios::binary);
		if(!input.is_open())	return false;
		Read_Binaries(input, M, number);
		
		int data_length=0;
		for(int id=0; id<ni*nj; id++)
			if(M[id]!=EMPTY_MASK)	data_length++;

		TYPE* data=new TYPE[data_length*4];			
		Read_Binaries(input, data, data_length*4);

		for(int id=0, ptr=0; id<ni*nj; id++)
		if(M[id]!=EMPTY_MASK)	
		{
			G[id*4+0]=data[ptr*4+0];
			G[id*4+1]=data[ptr*4+1];
			G[id*4+2]=data[ptr*4+2];
			G[id*4+3]=data[ptr*4+3];
			ptr++;
		}
		delete[] data;

		input.close();
		return true;
	}
};

